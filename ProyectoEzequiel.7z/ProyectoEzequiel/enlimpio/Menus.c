#include <stdio.h>
#include <stdlib.h>
#include <conio.h>



#include "Menus.h"
#include "usuarios.h"
#include "canciones.h"


#define AR_CANCIONES "canciones.dat"
#define AR_USUARIOS "usuarios.dat"


void MenuPrincipal()
{
    int opcion=0;

    printf("-------------- BIENVENIDO, EMPRESA JORGITO --------------\n\n");
    system("pause");
    while(opcion==0){
        system("cls");
        printf("MENU PRINCIPAL\n\n");
        printf("1- INGRESAR COMO USUARIO\n");
        printf("2- REGISTRARSE\n");
        printf("3- SALIR\n\n");

        printf("OPCION: ");
        fflush(stdin);
        scanf("%d", &opcion);

        switch(opcion){
            case 1:
                menuLogin();
                break;
            case 2:
                menuRegistro();
                break;
            case 3:
                break;
            default:
                opcion=0;
                break;

        }
    }
}


void menuLogin()
{
    stUsuario u;
    char nombreUsuario[30];
    int flag=0;

    do{
        system("cls");
        printf("LOGIN\n\n");
        printf("INGRESE USUARIO: ");
        fflush(stdin);
        gets(nombreUsuario);

        ///FUNCION QUE VERIFICA SI UN USUARIO EXISTE EN BASE DE DATOS
        flag=existeUsuario(nombreUsuario);

        if(flag==1){///Se encontr� el usuario
            ///FUNCION QUE RETORNA UN USUARIO POR CHAR Y DEVUELVE LA ESTRUCTURA PARA VERIFICAR LA PASS
            u=BuscaUsuarioPorChar(nombreUsuario);
        }
        else{
            printf("\nUsuario Incorrecto.");
        }
    }while(flag==0);

    do {
        printf("\nINGRESE CLAVE: ");
        char pass[20];
        gets(pass);


    ///VALIDACION CLAVE DE USUARIO Y TIPO DE USUARIO

        if(strcmp(pass, u.pass)==0){
            flag=2;
            if(u.tipoUsuario==0)///si es usuario comun
            {
                menuUsuario(u);
            }
            if(u.tipoUsuario==1)///si es admin
            {
                menuAdmin(u); ///USER Y PASS ADMIN ADMIN
            }
        }
        else{
            printf("\n Password Incorrecto");
        }
    }while(flag==1);
    ///SEGUN TIPO DE USUARIO VA A MENU USUARIO O MENU ADMIN
}

void menuRegistro(){
    stUsuario usuario;

    system("cls");
    usuario = cargarDatosRegistro(usuario);

    int guardado = guardarUsuario(usuario);

    if(guardado == 0) {
        MenuPrincipal();
    } else {
        menuLogin();
    }
}

/// printf("2- MOSTRAR PLAYLIST\n"); TENDRIA QUE SER -> TODAS LAS PLAYLIST
/// printf("3- MOSTRAR PLAYLIST USUARIO\n"); TENDRIA QUE SER OTRA OPCION CON LAS FUNCIONES QUE TIENE HECHAS NAHUEL.
void menuUsuario(stUsuario u)
{
    int opcion=0;
    while(opcion==0){
        system("cls");
        printf("BIENVENIDO, %s | MENU USUARIO\n\n", u.nombreUsuario);
        printf("1- VER PERFIL\n");
        printf("2- MOSTRAR PLAYLIST\n");
        printf("3- MOSTRAR PLAYLIST USUARIO\n");
        printf("4- AGREGAR CANCION A PLAYLIST\n");
        printf("5- BUSCAR CANCION\n"); ///BUSCAR CANCION, ESTA HECHO, PODES BUSCARLO DE LAS FUNCIONES QUE TE PASO EN EL MAIN SUELTO Y DEL OTRO TP
        printf("6- CERRAR SESION\n\n");
        printf("OPCION: ");
        fflush(stdin);
        scanf("%d", &opcion);

        switch(opcion){
            case 1:
                MuestraUnUsuario(u);
                system("pause");
                menuUsuario(u);
                break;
            case 2:
                ///mostrarPlaylist();
                system("pause");
                menuUsuario(u);
                break;
            case 3:
                ///buscarCancion();
                system("pause");
                menuUsuario(u);
                break;
            case 4:
                system("cls");
                MenuPrincipal();
            default:
                opcion=0;
        }
    }
}


void menuAdmin(stUsuario u)
{
    int opcion=0;
    while(opcion==0){
        system("cls");
        printf("BIENVENIDO, %s | MENU ADMINISTRADOR\n\n", u.nombreUsuario);
        printf("1- VER PERFIL\n");
        printf("2- GESTIONAR CANCIONES\n");
        printf("3- GESTIONAR USUARIOS\n");
        printf("4- CERRAR SESION\n\n");
        printf("OPCION: ");
        fflush(stdin);
        scanf("%d", &opcion);

        switch(opcion){
            case 1:
                MuestraUnUsuario(u);
                system("pause");
                menuAdmin(u);
                break;
            case 2:
                menuGestionarCanciones(u);
                break;
            case 3:
                menuGestionarUsuarios(u);
                break;
            case 4:
                system("cls");
                MenuPrincipal();
            default:
                opcion=0;
        }
    }
}

void menuGestionarCanciones(stUsuario u){
    //Creamos un arbol
    ArbolCanciones* arbolCancion;
    arbolCancion = inicListaC();
    pasarArchCancionToArbol(&arbolCancion);

    int opcion=0;
    while(opcion==0){
        system("cls");
        printf("MENU GESTIONAR CANCIONES\n\n");
        printf("1- ALTA\n");
        printf("2- BAJA\n");
        printf("3- MODIFICACION\n");
        printf("4- LISTADO\n");
        printf("5- VOLVER ATRAS\n\n");
        printf("OPCION: ");
        fflush(stdin);
        scanf("%d", &opcion);

        switch(opcion){
            case 1:
                //altaCancion(); podemos ponerlo adentro de esta funcion
                stCancion cancion = cargarCancion(cancion);
                ///NO ESTA -> HABRIA QUE REPLICARLA CON ALGUNA FUNCION QUE TENGA CARGA DE CANCIONES DESDE UN ARBOL
                ///LAS TENGO HECHAS EN OTRO PROYECTO QUE TAMBIEN LO DEJO, PERO CON QUE SOLAMENTE ESTE EL PROTOTIPADO DE LA FUNCION ME ALCANZA
                menuAdmin(u);
                break;
            case 2:
                ///bajaCancion();
                ///NO ESTA -> HABRIA QUE REPLICARLA CON ALGUNA FUNCION SACADA DEL OTRO PROYECTO
                menuAdmin(u);
                break;
            case 3:
                ///modificarCancion(); DE MODIFICAR NO HAY NADA!
                ///NO ESTA -> HABRIA QUE REPLICARLA CON ALGUNA FUNCION SACADA DEL OTRO PROYECTO
                menuAdmin(u);
                break;
            case 4:
                muestraArchivoCancion();
                system("pause");
                menuAdmin(u);
                break;
            case 5:
                menuAdmin(u);
                break;
            default:
                opcion=0;
        }
    }
}

void menuGestionarUsuarios(stUsuario u){
    int opcion=0;
    while(opcion==0){
        system("cls");
        printf("MENU GESTIONAR USUARIOS\n\n");
        printf("1- ALTA\n");
        printf("2- BAJA\n");
        printf("3- MODIFICACION\n");
        printf("4- LISTADO\n");
        printf("5- VOLVER ATRAS\n\n");
        printf("OPCION: ");
        fflush(stdin);
        scanf("%d", &opcion);

        switch(opcion){
            case 1:
                ///altaUsuario();
                ///SE PUEDE REPLICAR DE LOGIN()
                break;
            case 2:
                ///bajaUsuario();
                ///BUSCARLO EN OTRO PROYECTO
                menuAdmin(u);
                break;
            case 3:
                ///modificarUsuario();
                ///BUSCARLO EN OTRO PROYECTO
                menuAdmin(u);
                break;
            case 4:
                muestraArchivoUsuario();
                system("pause");
                menuAdmin(u);
            case 5:
                menuAdmin(u);
                break;
            default:
                opcion=0;
        }
    }
}
