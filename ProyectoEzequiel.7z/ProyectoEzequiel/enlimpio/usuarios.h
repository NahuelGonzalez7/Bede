#ifndef USUARIOS_H_INCLUDED
#define USUARIOS_H_INCLUDED


#include "canciones.h"
#define AR_CANCIONES "canciones.dat"
#define AR_USUARIOS "usuarios.dat"


typedef struct {
 int idUsuario;
 int tipoUsuario; //indica 0 si es usuasrio comun, 1 si es admin
 char nombreUsuario[30];
 char pass[20];
 int anioNacimiento;
 char genero;
 char pais[20];
 int eliminado; // indica 1 o 0 si el cliente fue eliminado
} stUsuario;

typedef struct ArbolUsuarios ArbolUsuarios;
 typedef struct ArbolUsuarios{
    stUsuario dato;
    nodoCancion *favoritas;
    ArbolUsuarios *izq;
    ArbolUsuarios *der;
};


///USUARIOS
ArbolUsuarios* inicListaU();
ArbolUsuarios* crearNodoUsuario (stUsuario dato);///no anda
ArbolUsuarios* agregarUsuario (ArbolUsuarios* arbol, stUsuario dato);
void mostrarNodoArbolU(ArbolUsuarios *arbol);
void preorderU (ArbolUsuarios* arbol);
void inorderU(ArbolUsuarios* arbol);
void MuestraUnUsuario(stUsuario u);
ArbolUsuarios* pasarArchUsuarioToArbol();
int existeUsuario(char nombreUsuario[]);
stUsuario BuscaUsuarioPorChar(char nombreUsuario[]);
int guardarUsuario(stUsuario u);
stUsuario cargarDatosRegistro(stUsuario u);
int altaUsuario(ArbolUsuarios * arbol, stUsuario usuario);
int bajaUsuario(ArbolUsuarios * arbol, stUsuario usuario);

///CargaRND
stUsuario cargaUsuarioRandom ();
void getNombresRand(char n[]);
void getPassRand(char n[]);
int getNumRand();
void getPaisRand(char n[]);
void getGeneroRand(char n[]);


#endif // USUARIOS_H_INCLUDED
