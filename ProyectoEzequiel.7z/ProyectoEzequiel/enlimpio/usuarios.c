#include "usuarios.h"
#include "string.h"
#include "canciones.h"
///USUARIOS///

///ARBOL USUARIOS

ArbolUsuarios* inicListaU()
{
    return NULL;
}

ArbolUsuarios* crearNodoUsuario (stUsuario dato){
    ArbolUsuarios* aux = (ArbolUsuarios*) malloc(sizeof(ArbolUsuarios));

    aux->dato = dato;
    aux->der = NULL;
    aux->izq = NULL;

    return aux;
}

ArbolUsuarios* agregarUsuario (ArbolUsuarios* arbol, stUsuario dato){
    if (arbol == NULL){
        printf("\nENTRA AL IF\n");

        arbol = crearNodoUsuario(dato);

         if(arbol->dato.idUsuario == 0)
         {
             arbol->dato.idUsuario = GenerarIDUnicoUsuarios(arbol);
         }
    }
    else if (dato.idUsuario > (arbol->dato.idUsuario))
        {
            printf("\nENTRA AL ELSE IF\n");
            printf("DATO USUARIO: %d\n", dato.idUsuario);
            printf("DATO ARBOL: %d\n", arbol->dato.idUsuario);

            return agregarUsuario(&arbol->der, dato);
        } else {
            printf("\nENTRA AL ELSE ELSE\n");

            return agregarUsuario(&arbol->izq, dato);
        }
    return arbol;
}


///MOSTRAR

void preorderU (ArbolUsuarios* arbol){
    if(arbol!=NULL)
        {
            mostrarNodoArbolU(arbol);
            preorderU(arbol->izq);
            preorderU(arbol->der);
        }
}

void inorderU(ArbolUsuarios* arbol)
{
    if(arbol!= NULL)
    {
        preorderU(arbol->izq);
        mostrarNodoArbolU(arbol);
        preorderU(arbol->der);
    }
}

void mostrarNodoArbolU(ArbolUsuarios *arbol)
{
    if(arbol)
    {
        MuestraUnUsuario(arbol->dato);
    }
}

void MuestraUnUsuario(stUsuario u)
{
    printf("\n==========");
    printf("\nUSER: %d",u.idUsuario);
    printf("\nNOMBRE: %s",u.nombreUsuario);
    printf("\nPASSWORD: %s",u.pass);
    printf("\nNACIMIENTO: %d",u.anioNacimiento);
    printf("\nGENERO: %c",u.genero);
    printf("\nPAIS: %s",u.pais);
    printf("\nELIMINADO: %d",u.eliminado);
    printf("\n==========\n");
}


///ID USUARIOS

int GenerarIDUnicoUsuarios(ArbolUsuarios* arbol) ///genera un id unico, revisando un arbol usuarios
{
    int flag=0,id;

        do{
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolU(arbol,id)==0)
        {
            flag=1;
        }
        }while(flag!=1);

    return id;
}


int buscaIDenArbolU (ArbolUsuarios *arbol, int id) ///busca un id en arbol usuarios, retorna un flag
{
    int flag=0;

        if (arbol)
            {
            if (id == arbol->dato.idUsuario)
                {
                    flag=1;
                }
            else
                if (id > arbol->dato.idUsuario)
                    {
                    flag = buscaIDenArbolU(arbol->izq,id);
                    }
                else
                    {
                    flag = buscaIDenArbolU(arbol->der,id);
                    }
            }
    return flag;
}


/// PASAJE A ARCHIVO USUARIOS
 ArbolUsuarios* pasarArchUsuarioToArbol()
 { ///Cargar un arbol de un archivo
    ArbolUsuarios *arbol = inicListaU();
    FILE *pArchusuarios = fopen(AR_USUARIOS, "rb");
    //stCancion aux;
    stUsuario usuarioAux;
    if (pArchusuarios){
        while (fread(&usuarioAux, sizeof(stUsuario), 1, pArchusuarios)>0){
            system("pause");
            arbol = agregarUsuario(arbol,usuarioAux);
            mostrarNodoArbolU(&arbol);
            ///Falta implementar esta parte, agregarle una lista de canciones personal del usuario
            //ArbolCanciones* cons = crearNodoCancion(aux); ///Crea lista doble de playlist.
        }

        fclose(pArchusuarios);
    }
    return arbol;
}

void GuardaUsuarioEnArchivo (ArbolUsuarios *arbol,FILE *pArchusuarios)
{
    if(pArchusuarios)
        {
            if(arbol != NULL)
            {
                fwrite(&arbol->dato, sizeof (stUsuario),1,pArchusuarios);
                GuardaUsuarioEnArchivo(arbol->izq,pArchusuarios);
                GuardaUsuarioEnArchivo(arbol->der,pArchusuarios);
                ///falta guardar una lista de canciones nodoCanciones vinculada del usuario
                fclose(pArchusuarios);
                printf("\n cargado exitosa");
            }

        }
}

void muestraArchivoUsuario()
{
     FILE *pArchusuarios = fopen(AR_USUARIOS, "rb");
     stUsuario usuarioAux;
     if(pArchusuarios)
     {
         while(fread(&usuarioAux, sizeof(stUsuario), 1, pArchusuarios)>0)
         {
            MuestraUnUsuario(usuarioAux);
         }
         fclose(pArchusuarios);
     }

}

int existeUsuario(char nombreUsuario[]){
    int flag = 0;
    FILE *pArchusuarios = fopen(AR_USUARIOS, "rb");
     stUsuario usuarioAux;
     if(pArchusuarios)
     {

         while(fread(&usuarioAux, sizeof(stUsuario), 1, pArchusuarios)>0)
         {
            if(strcmp(usuarioAux.nombreUsuario, nombreUsuario)==0){
                flag = 1;
                return flag;
            }
         }
         fclose(pArchusuarios);
     }

     return flag;

}

stUsuario BuscaUsuarioPorChar(char nombreUsuario[]){
    FILE *pArchusuarios = fopen(AR_USUARIOS, "rb");
     stUsuario usuarioAux;
     if(pArchusuarios)
     {
         while(fread(&usuarioAux, sizeof(stUsuario), 1, pArchusuarios)>0)
         {
            if(strcmp(usuarioAux.nombreUsuario, nombreUsuario)==0){
                fclose(pArchusuarios);
                return usuarioAux;
            }
         }
         fclose(pArchusuarios);
     }
}

int guardarUsuario(stUsuario u){
    int flag = 0;
    FILE *pArchusuarios = fopen(AR_USUARIOS, "ab");
    if(pArchusuarios)
     {
         stUsuario aux;
         aux = BuscaUsuarioPorChar(u.nombreUsuario);
         if(strcmp(aux.nombreUsuario, u.nombreUsuario)!=0) {
            fwrite(&u, sizeof(stUsuario), 1, pArchusuarios);
            flag = 1;
         }
         fclose(pArchusuarios);
     }
     return flag;
}

stUsuario cargarDatosRegistro(stUsuario usuario){
    printf("REGISTRO\n\n");

    printf("INGRESE USUARIO: ");
    fflush(stdin);
    gets(usuario.nombreUsuario);

    printf("\nINGRESE PASSWORD: ");
    fflush(stdin);
    gets(usuario.pass);

    printf("\nINGRESE ANIO DE NACIMIENTO: ");
    fflush(stdin);
    scanf("%d", &usuario.anioNacimiento);

    printf("\nINGRESE GENERO: ");
    fflush(stdin);
    scanf("%c", &usuario.genero);

    printf("\nINGRESE PAIS: ");
    fflush(stdin);
    gets(usuario.pais);

    usuario.eliminado = 0;
    usuario.tipoUsuario = 0;

    return usuario;
}

int altaUsuario(ArbolUsuarios * arbol, stUsuario usuario){
    arbol = pasarArchUsuarioToArbol();
    ///FALTA UNA FUNCION PARA QUE BUSQUE EL USUARIO EN EL ARBOL Y MODIFIQUE EL ELIMINADO = 0 EN CASO DE QUE ESTE ELIMINADO Y RECIEN AHI GUARDAR EN EL ARCHIVO.
}

///CARGA RND USUARIOS

stUsuario cargaUsuarioRandom()
{
    stUsuario u;

    u.idUsuario=0;
    getNombresRand(u.nombreUsuario);
    getPassRand(u.pass);
    u.anioNacimiento=getNumRand();
    u.genero='v';
    getPaisRand(u.pais);
    u.eliminado=0;
    u.tipoUsuario=0;

    return u;
}

void getNombresRand(char nya[])
{
    char n[30];
    char nombres [][30] = {"Pedro", "Pablo", "Pilar", "Lucas","Micaela", "Adrian","Lucia","Jeremias","Belen",
                           "Milagros","Tomas","Martin","Sergio","Victoria","Andrea","Luciano","Romina","Franco","Valentina","Melanie",
                           "Guadalupe","Manuel","Carlos","Andrea","Sebastian","Antonio","John","Rocio"
                          };
    strcpy (n, nombres[rand()%(sizeof(nombres)/30)]);

    char a[30];
    char apellidos [][30] = {"Lopez","Fernandez","Acu�a","Martinez","Botero","Verstappen","Alonso","Perez","Leclerc",
                             "Sainz","Norris","Gasly","Vettel","Ricciardo","Senna","Reutemann","Fangio","Barrichello","Hamilton","Trulli","Mansell",
                             "McLaren","Benz","Martin","Williams","Haas","Martinez","Fernandez","Echeverria","Navarro",
                            };
    strcpy (a, apellidos[rand()%(sizeof(apellidos)/30)]);
    sprintf(nya,"%s %s",n,a);

}

void getPassRand(char n[])
{
    char pass [][30] = {"asdasd", "Pazczxblo", "zxczxadwq", "qqwewqe","cvbcvb", "tytyerwer","qweqwe","sdfsdfsd","ncvnbvn",
                           "qweqwe","ertert","tyuty","xcvvxcv","asdas","punbvn","sdfger","asdqwe123","4534zdfx","6436cvx","123124zxc",
                           "zxczxvxc34634","123123zxdc","asdasd23565","hjghjdf421","dsad1325t34","asdaswd123","hjklh213","klkl345"
                          };
    strcpy(n, pass[rand()%(sizeof(pass)/30)]);
}

int getNumRand()
{
    srand(time(NULL));
    int num= rand() % 100000;
    return num;
}

void getPaisRand(char n[])
{
    char pais [][30] = {"Argentina", "Brasil", "Peru", "Chile","Inglaterra", "Suecia","Holanda","Suiza","Hong Kong",
                           "Paraguay","Francia","Alemania","Portugal","Indonesia","Tunez","Siria","Israel","Estados Unidos","Uruguay","Argelia",
                           "Australia","Nueva Zelanda","Canada","Arabia Saudita","Iran","Mexico","Rusia","Ucrania"
                          };
    strcpy(n, pais[rand()%(sizeof(pais)/30)]);
}
