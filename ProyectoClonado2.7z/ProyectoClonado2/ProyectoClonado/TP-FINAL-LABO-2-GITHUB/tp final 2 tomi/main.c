#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "playlist.h"

#define AR_CANCIONES "canciones.dat"

///


int main()
{


}


///FUNCIONES DE IDS
int GenerarIDUnico(arbolPadre* arbol) ///genera un id unico, revisando un arbol dado
{
    int flag=0,id;
    do{
        srand(time(NULL));
        id=rand() % 10000;
        if (buscaIDenArbolC(arbol->arbolC ,id)==0)///busca en canciones
        {
            flag=1;
        }
        if (buscaIDenArbolU(arbol->arbolU ,id)==0)///busca en usuarios
        {
            flag=1;
        }
    }while(flag!=1);

    return id;
}













void GuardaTDAenArchivo(char archivo[]) ///GUARDA PLAYLISTS EN ARCHIVO
{
FILE*archi=fopen(archivo,"Playlist.dat");
    if(archi)
    {

        fclose(archi);
    }
}

