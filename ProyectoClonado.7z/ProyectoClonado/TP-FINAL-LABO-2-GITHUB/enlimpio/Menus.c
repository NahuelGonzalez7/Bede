#include <stdio.h>
#include <stdlib.h>
#include <conio.h>



#include "Menus.h"
#include "usuarios.h"
#include "canciones.h"


#define AR_CANCIONES "canciones.dat"
#define AR_USUARIOS "usuarios.dat"

/*
void MenuPrincipal ()
{

    printf("/n EMBPRESA JORGITO");
    printf("/n PRESIONE CUALQUIER TECLA PARA INGRESAR");
    system("Pause");
    Login();

}


void login()
{
    stUsuario u;
    char usuario;
    int flag=0;
    do
    {
        printf("\nINGRESE USUARIO: ");
        gets(usuario);
        ///FUNCION QUE BUSCA USUARIO POR CHAR Y DEVUELVE LA ESTRUCTURA PARA VERRIFICAR LA PASS
        u=BuscaUsuarioPorChar(usuario);

        if() ///usuario valido
        {
            flag=1
        }
        else()
        {
            printf("\nUsuario Incorrecto.")
        }
    } while(flag!=1);




    do
    {
        printf("\nINGRESE CLAVE: ");
        char clave= gets();


        ///VALIDACION CLAVE DE USUARIO Y TIPO DE USUARIO

        if(strncmp(clave, u.pass)==0)
        {
            if(u.tipoUsuario==0)///si es usuario comun
            {
                MenuUsuario();
                flag=2;
            }
            if(u.tipoUsuario==1)///si es admin
            {
                menuAdmin();
                flag=2;
            }

        }
        else()
        {
            printf("\n incorrecto")
        }
    } while(flag!=2);
    ///SEGUN TIPO DE USUARIO VA A MENU USUARIO O MENU ADMIN





}

void menuUsuario()
{
    printf("\n"); ///PONER OPCIONES

}


void menuAdmin()
{
    printf("\n");/// PONER OPCIONES


}

*/
