#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include "usuarios.h"
#include "canciones.h"

#define AR_CUSUARIOS "cancionesUsuarios.dat"
#define AR_CANCIONES "canciones.dat"
#define AR_USUARIOS "usuarios.dat"


///ST BASICAS



///TDA PLAYLIST
typedef struct TDAPlaylist{
    nodoCancion *playlist;
    char titulo[20];
}TDAPlaylist;



int BuscaCancionXString(ArbolCanciones *arbol,char string,int flag);///busca una cancion por string, si la encuentra devuelve el ID. Si recibe flag 1 busca artista, flag 2 busca genero
int CargarPlaylistGenero(TDAPlaylist playlist[],ArbolCanciones *arbol,int dim);



int main()
{
///Prueba Usuarios


    ArbolUsuarios *arbolAux = inicListaU();
    stUsuario user;
    int idUsuario = user.idUsuario;
    ArbolUsuarios *arbolU = inicListaU();

    /*
    printf("entro al for \n");
    for(int i=0;i<10;i++)
    {
        user = cargaUsuarioRandom();
        agregarUsuario(&arbolU,user);
        printf("agrege \n");
        sleep(1);
    }

    //printf("salio del for");
    //inorderU(arbolU);

    FILE *pArchusuarios = fopen(AR_USUARIOS,"ab");
    GuardaUsuarioEnArchivo(arbolU,pArchusuarios);
    //printf("archivo guardado");

    */
    muestraArchivoUsuario();
    system("pause");
    //pasarArchUsuarioToArbol(&arbolAux);
     //muestraArchivoUsuario();
    //printf("\n archivo cargado");
    //inorderU(arbolAux);
    //printf("hola");
    //arbolU = buscarUsuario(arbolAux,2697);
    //mostrarNodoArbolU(arbolU);

///prueba Canciones

    ArbolCanciones *arbolAuxC = inicListaC();
    stCancion cancion;
    ArbolCanciones *arbolC= inicListaC();
    //nodoCancion* lista = inicNodoC();

    /*
    user = cargaUsuarioRandom();
    idUsuario = agregarUsuario(&arbolU,user);
    printf("IdUsuario %d \n",idUsuario);
    for(int i=0;i<10;i++)
    {
        //nodoCancion* nuevoNodo = crearNodoCancionFavorita(arbolC,idUsuario);
        //lista = agregarAlPrincipio(lista,nuevoNodo);
        cancion=cargaCancionRandom();
        nodoCancion* nuevoNodo = crearNodoCancionFavorita(cancion,idUsuario);
        lista = agregarAlPrincipio(lista,nuevoNodo);
        sleep(1);
    }
    */

    //inorderCancion(arbolC);
    //inorderU(arbolU);
    //muestraListadobleIterar(lista);
    //system("pause");
    //FILE *pArchCanciones= fopen(AR_CANCIONES,"a");
    //pasarListaToArchivo(lista,pArchCanciones);
    //mostrarCancionFavoritaArchivo();
    //mostrarCancionFavoritaArchivoTest();







    ///VIEJOS METODOS DE LINKEO
    //guardarCancionFavoritaEnArchivo(lista,pArchCanciones);
    //printf("MUESTRA ARCHIVO \n\n");
    //muestraArchivoCancionFavorita();

    /*


    for(int i=0;i<10;i++)
    {
        cancion=cargaCancionRandom();
        AgregarCancion(&arbolC,cancion);
        sleep(1);
    }
    FILE *pArchCanciones= fopen(AR_CANCIONES,"ab");

    GuardaCancionEnArchivo(arbolC,pArchCanciones);
    */


    //muestraArchivoCancion();
    //agregarCancionAUsuario();


   // muestraArchivoCancion();

    //pasarArchCancionToArbol(&arbolAuxC);
    //inorderCancion(arbolAuxC);
    //system("PAUSE");
    //arbolC = buscarCancion(arbolAuxC,7883);
    //mostrarNodoArbolCancion(arbolC);


    ///SOLO AGREGA A LISTA

    /*
    pasarArchCancionToArbol(&arbolAuxC);
    inorderCancion(arbolAuxC);
    char control = 's';
    int idCancion;
    int idLista;
    nodoCancion* lista = inicNodoC();
    while(control == 's')
    {
        printf("ingrese id cancion:");
        fflush(stdin);
        scanf("%i",&idCancion);
        arbolC = buscarCancion(arbolAuxC,idCancion);
        printf("Encontro la cancion");
        //mostrarNodoArbolCancion(arbolC); ///TRAE BIEN LA CANCION
        nodoCancion* nuevoNodo = crearNodoCancionFavorita(arbolC->dato,idUsuario);
        //mostrarNodoLista(nuevoNodo); ///AGREGO BIEN CANCION A NUEVO NODO
        lista = agregarAlPrincipio(lista,nuevoNodo); ///FUNCIONA BIEN
        //muestraListadobleIterar(lista);
        printf("Cancion agregada \n\n");
        printf("Desea continuar ingresando? \n");
        fflush(stdin);
        scanf("%c",&control);
    };
    muestraListadobleIterar(lista);
    system("pause");

    */
    //FILE *pArchCanciones= fopen(AR_CANCIONES,"a");
    //pasarListaToArchivo(lista,pArchCanciones);
    mostrarCancionFavoritaArchivo();
    system("pause");
    pasarArchivoCancionesFavoritasToArbol(&arbolU);
    //printf("PASADO AL ARBOL CORRECTAMENTE");
    //printf("MUESTRA EL ARBOL");
   // muestraListadobleIterar(arbolU);


   // printf("ingrese id de la lista que quiere buscar:");
   // fflush(stdin);
   // scanf("%i",&idLista);
    //agregarCancionAUsuario(lista,&arbolU);
    //mostrarCancionFavoritaPorUsuario(arbolU);




    //FILE *pArchusuarios = fopen(AR_CUSUARIOS,"ab");
    //GuardaUsuarioEnArchivo(arbolU,pArchusuarios);

    ///GUARDAR UN SOLO USER Y LISTA DE CANCIONES
    //FILE *pArchusuarios = fopen(AR_CUSUARIOS,"ab");
    //GuardaUsuarioEnArchivo(arbolU,pArchusuarios);
    //muestraArchivoCancionesUsuario();

    //muestraArchivoUsuario();


///prueba nodoCancion;
/*
    int id1=7879;
    int id2=7866;
    nodoCancion* lista=inicNodoC();
    AgregarNodo(&lista,arbolC,id1);
    AgregarNodo(&lista,arbolC,id2);
    MuestraListaDoble(lista);
*/

    TDAPlaylist playlist[30];

    /*
    char control = 's';
    int idCancion;
    //mostrarNodoArbolCancion(arbolC);
    //cancionEncontrada = buscarCancion(arbolC,idCancion);
    ///FUNCIONANDO, HAY QUE VER COMO PASAR POR PARAMETRO LAS COSAS
    //arbolU->favoritas = crearNodoCancion(arbolC);
    while(control == 's')
    {
        printf("ingrese id cancion:");
        fflush(stdin);
        scanf("%i",&idCancion);
        arbolC = buscarCancion(arbolAuxC,idCancion);
        printf("Encontro la cancion, se agregara a su lista de usuarios \n");
        agregarCancionAUsuario(arbolC,&arbolU);
        printf("Cancion agregada \n\n");
        //inorderAgregarCancionU(arbolU);
        printf("Desea continuar ingresando? \n");
        fflush(stdin);
        scanf("%c",&control);
    };
    muestraListadobleIterar(arbolU->favoritas);
    */
    //mostrarCancionFavoritaPorUsuario(arbolU);
    //preorderAgregarCancionU(arbolU);


    return 0;
}


void muestraArchivoCancionesUsuario()
{
    FILE *pArchCancionesUsuarios = fopen(AR_CUSUARIOS, "rb");
     stUsuario usuarioAux;
     //nodoCancion* favoritas;
     if(pArchCancionesUsuarios)
     {
         while(fread(&usuarioAux, sizeof(stUsuario), 1, pArchCancionesUsuarios)>0)
         {
            MuestraUnUsuario(usuarioAux);
            //muestraListadobleIterar(favoritas);
         }
         fclose(pArchCancionesUsuarios);
     }
}


///Carga TDA PLAYLIST

int CargarPlaylistGenero(TDAPlaylist playlist[],ArbolCanciones *arbol,int dim)
{

    int validos=0,continuar=1;
    nodoCancion* lista = inicNodoC;

    for(int i = 0;i<dim && continuar == 1;i++)
    {

        ///playlist[i].titulo=;
        CargaListaPorChar(&lista,arbol,playlist[i].titulo,2);
    }



    return validos;
}


void CargaListaPorChar(nodoCancion **lista, ArbolCanciones *arbol, char string, int flag) ///Recibe el arbol de canciones, la lista donde carga las canciones y 1 para buscar un artista, 2 para buscar un genero
{
int id;

if(arbol)
{
    do
        {
        id=BuscaCancionXString(arbol,string,flag);
        BuscaCancionXID(*(&lista),arbol,id);

        ///CargaListaPorChar(*(&lista->sig),arbol->)
        ///Falta funcion que agrega la cancion encontrada a la lista

        }while(id!=0);
}



}

int BuscaCancionXString(ArbolCanciones *arbol,char string,int flag)///busca una cancion por string, si la encuentra devuelve el ID. Si recibe flag 1 busca artista, flag 2 busca genero
{
   int id=0;
    if(arbol)
    {
        if(flag==1)///busca artista
        {
            if(strcmp(string,arbol->dato.artista)==0)
            {
                id=arbol->dato.idCancion;
            }
            else
                {
                    id=BuscaCancionXString(arbol->izq,string,flag);
                    if(id == NULL)
                    {
                        id = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return id;
        }

        if(flag==2)///busca genero
        {
            if(strcmp(string,arbol->dato.genero)==0)
            {
                id=arbol->dato.idCancion;
            }
            else
                {
                    id=BuscaCancionXString(arbol->izq,string,flag);
                    if(id == NULL)
                    {
                        id = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return id;
        }

    }
}



void BuscaCancionXID (nodoCancion **lista,ArbolCanciones *arbol, int id) ///busca un id en arbol canciones, si lo encuentra lo agrega a la lista con puntero doble que recibe
{
    ArbolCanciones *iterator=arbol;
        if (iterator)
            {
            if (id == iterator->dato.idCancion)
                {
                    (*lista)= crearNodoCancion(iterator->dato);
                }
            else
                {
                if (id > iterator->dato.idCancion)
                    {
                    BuscaCancionXID(&(*lista),iterator->der,id);
                    }
                else
                    {
                    BuscaCancionXID(&(*lista),iterator->izq,id);
                    }
                }

            }
}



///CANCIONES







