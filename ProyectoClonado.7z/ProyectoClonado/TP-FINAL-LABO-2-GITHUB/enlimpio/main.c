#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include "usuarios.h"
#include "canciones.h"


#define AR_CANCIONES "canciones.dat"
#define AR_USUARIOS "usuarios.dat"

///ST BASICAS



///TDA PLAYLIST
typedef struct TDAPlaylist{
    nodoCancion *playlist;
    char titulo[20];
}TDAPlaylist;



int BuscaCancionXString(ArbolCanciones *arbol,char string,int flag);///busca una cancion por string, si la encuentra devuelve el ID. Si recibe flag 1 busca artista, flag 2 busca genero
int CargarPlaylistGenero(TDAPlaylist playlist[],ArbolCanciones *arbol,int dim);



int main()
{
///Prueba Usuarios


    ArbolUsuarios *arbolAux = inicListaU();
    stUsuario user;
    ArbolUsuarios *arbolU = inicListaU();

    /*
    for(int i=0;i<10;i++)
    {
        user = cargaUsuarioRandom();
        agregarUsuario(&arbolU,user);
        printf("hola");
        sleep(2);

    }
    preorderU(arbolU);
    */


    //FILE *pArchusuarios = fopen(AR_USUARIOS,"ab");
    //GuardaUsuarioEnArchivo(arbolU,pArchusuarios);
    //muestraArchivoUsuario();

    pasarArchUsuarioToArbol(&arbolAux);

    //printf("\n archivo cargado");
    //inorderU(arbolAux);
    //printf("hola");
    arbolU = buscarUsuario(arbolAux,1000);
    //mostrarNodoArbolU(arbolU);

///prueba Canciones

    ArbolCanciones *arbolAuxC = inicListaC();
    stCancion cancion;
    ArbolCanciones *arbolC= inicListaC();
    /*
    ArbolCanciones *arbolC= inicListaC();

    for(int i=0;i<10;i++)
    {
        cancion=cargaCancionRandom();
        AgregarCancion(&arbolC,cancion);
        sleep(1);
    }
    FILE *pArchCanciones= fopen(AR_CANCIONES,"ab");

    GuardaCancionEnArchivo(arbolC,pArchCanciones);



    muestraArchivoCancion();
    //agregarCancionAUsuario();

    */
    //muestraArchivoCancion();
    /*
    pasarArchCancionToArbol(&arbolAuxC);
    inorderCancion(arbolAuxC);
    system("PAUSE");
    char control = 's';
    int idCancion;
    //mostrarNodoArbolCancion(arbolC);
    //cancionEncontrada = buscarCancion(arbolC,idCancion);
    ///FUNCIONANDO, HAY QUE VER COMO PASAR POR PARAMETRO LAS COSAS
    //arbolU->favoritas = crearNodoCancion(arbolC);
    while(control == 's')
    {
        printf("ingrese id cancion:");
        fflush(stdin);
        scanf("%i",&idCancion);
        arbolC = buscarCancion(arbolAuxC,idCancion);
        printf("Encontro la cancion, se agregara a su lista de usuarios \n");
        agregarCancionAUsuario(arbolC,&arbolU);
        printf("Cancion agregada \n\n");
        //inorderAgregarCancionU(arbolU);
        printf("Desea continuar ingresando? \n");
        fflush(stdin);
        scanf("%c",&control);
    };
    mostrarCancionFavoritaPorUsuario(arbolU);
    //preorderAgregarCancionU(arbolU);

    */
    pasarArchCancionToArbol(&arbolAuxC);
    inorderCancion(arbolAuxC);
    char control = 's';
    int idCancion;
    nodoCancion* lista = inicNodoC();
    while(control == 's')
    {
        printf("ingrese id cancion:");
        fflush(stdin);
        scanf("%i",&idCancion);
        arbolC = buscarCancion(arbolAuxC,idCancion);
        nodoCancion* nuevoNodo = crearNodoCancion(arbolC);
        agregarAlPrincipio(lista,nuevoNodo);
        muestraListadobleIterar(lista);
        printf("Cancion agregada \n\n");
        printf("Desea continuar ingresando? \n");
        fflush(stdin);
        scanf("%c",&control);
    };
    muestraListadobleIterar(lista);


///prueba nodoCancion;
/*
    int id1=7879;
    int id2=7866;
    nodoCancion* lista=inicNodoC();
    AgregarNodo(&lista,arbolC,id1);
    AgregarNodo(&lista,arbolC,id2);
    MuestraListaDoble(lista);
*/

TDAPlaylist playlist[30];






    return 0;
}



/*
void getGeneroRand(char n[])///SOLO DEBE RETORNAR M O F
{
    char genero [][30] = {"Pedro", "Pablo", "Pilar", "Lucas","Micaela", "Adrian","Lucia","Jeremias","Belen",
                           "Milagros","Tomas","Martin","Sergio","Victoria","Andrea","Luciano","Romina","Franco","Valentina","Melanie",
                           "Guadalupe","Manuel","Carlos","Andrea","Sebastian","Antonio","Vera","Rocio"
                          };
    strcpy (n, genero[rand()%(sizeof(genero)/30)]);
}

*/







///Carga TDA PLAYLIST

int CargarPlaylistGenero(TDAPlaylist playlist[],ArbolCanciones *arbol,int dim)
{

    int validos=0,continuar=1;
    nodoCancion* lista = inicNodoC;

    for(int i = 0;i<dim && continuar == 1;i++)
    {

        ///playlist[i].titulo=;
        CargaListaPorChar(&lista,arbol,playlist[i].titulo,2);
    }



    return validos;
}


void CargaListaPorChar(nodoCancion **lista, ArbolCanciones *arbol, char string, int flag) ///Recibe el arbol de canciones, la lista donde carga las canciones y 1 para buscar un artista, 2 para buscar un genero
{
int id;

if(arbol)
{
    do
        {
        id=BuscaCancionXString(arbol,string,flag);
        BuscaCancionXID(*(&lista),arbol,id);

        ///CargaListaPorChar(*(&lista->sig),arbol->)
        ///Falta funcion que agrega la cancion encontrada a la lista

        }while(id!=0);
}



}

int BuscaCancionXString(ArbolCanciones *arbol,char string,int flag)///busca una cancion por string, si la encuentra devuelve el ID. Si recibe flag 1 busca artista, flag 2 busca genero
{
   int id=0;
    if(arbol)
    {
        if(flag==1)///busca artista
        {
            if(strcmp(string,arbol->dato.artista)==0)
            {
                id=arbol->dato.idCancion;
            }
            else
                {
                    id=BuscaCancionXString(arbol->izq,string,flag);
                    if(id == NULL)
                    {
                        id = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return id;
        }

        if(flag==2)///busca genero
        {
            if(strcmp(string,arbol->dato.genero)==0)
            {
                id=arbol->dato.idCancion;
            }
            else
                {
                    id=BuscaCancionXString(arbol->izq,string,flag);
                    if(id == NULL)
                    {
                        id = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return id;
        }

    }
}



void BuscaCancionXID (nodoCancion **lista,ArbolCanciones *arbol, int id) ///busca un id en arbol canciones, si lo encuentra lo agrega a la lista con puntero doble que recibe
{
    ArbolCanciones *iterator=arbol;
        if (iterator)
            {
            if (id == iterator->dato.idCancion)
                {
                (*lista)= crearNodoCancion(iterator);
                }
            else
                {
                if (id > iterator->dato.idCancion)
                    {
                    BuscaCancionXID(&(*lista),iterator->der,id);
                    }
                else
                    {
                    BuscaCancionXID(&(*lista),iterator->izq,id);
                    }
                }

            }
}



///CANCIONES







