#include "usuarios.h"
#include "canciones.h"


///USUARIOS///

///ARBOL USUARIOS

ArbolUsuarios* inicListaU()
{
    return NULL;
}

ArbolUsuarios* crearNodoUsuario (stUsuario dato){
    ArbolUsuarios* aux = (ArbolUsuarios*) malloc(sizeof(ArbolUsuarios));
    aux->dato = dato;
    aux->favoritas = inicNodoC();
    aux->der = NULL;
    aux->izq = NULL;

    return aux;
}

int agregarUsuario (ArbolUsuarios** arbol, stUsuario dato){

    ArbolUsuarios *iterator = *arbol;
    int idLista;
    if (iterator == NULL){
        (*arbol) = crearNodoUsuario(dato);
         if((*arbol)->dato.idUsuario == 0)
         {
             (*arbol)->dato.idUsuario = GenerarIDUnicoUsuarios(iterator);
             printf("%d idUsuario adentro de agregar usuario \n",(*arbol)->dato.idUsuario);
             //idLista=(*arbol)->dato.idUsuario;
             //printf(" printf adentro de agregar usuario antes de ir a funcion %d \n",idLista);
             //inicializarNodoCancion(idLista);
         }
        }
    else if (dato.idUsuario > (iterator->dato.idUsuario))
        {
            return agregarUsuario(&(iterator->der), dato);
        } else {
            return agregarUsuario(&(iterator->izq), dato);
        }
    return (*arbol)->dato.idUsuario;
}


///MOSTRAR

void preorderU (ArbolUsuarios* arbol){
    if(arbol!=NULL)
        {
            mostrarNodoArbolU(arbol);
            preorderU(arbol->izq);
            preorderU(arbol->der);
        }
}

void inorderU(ArbolUsuarios* arbol)
{
    if(arbol!= NULL)
    {
        preorderU(arbol->izq);
        mostrarNodoArbolU(arbol);
        preorderU(arbol->der);
    }
}

void mostrarNodoArbolU(ArbolUsuarios *arbol)
{
    if(arbol)
    {
        MuestraUnUsuario(arbol->dato);
    }
}

///PONER LINDO
void mostrarCancionFavoritaPorUsuario(ArbolUsuarios *arbol)
{
    if(arbol)
    {
         printf("\nUSER: %d",arbol->dato.idUsuario);
         muestraListadobleIterar(arbol->favoritas);
    }
}

void inorderAgregarCancionU(ArbolUsuarios* arbol)
{
    if(arbol!= NULL)
    {
        preorderU(arbol->izq);
        mostrarCancionFavoritaPorUsuario(arbol);
        preorderU(arbol->der);
    }
}

void preorderAgregarCancionU(ArbolUsuarios* arbol)
{
    if(arbol!= NULL)
    {
        preorderAgregarCancionU(arbol);
        preorderU(arbol->izq);
        preorderU(arbol->der);
    }
}

void MuestraUnUsuario(stUsuario u)
{
    printf("\n==========");
    printf("\nUSER: %d",u.idUsuario);
    printf("\nNOBMRE: %s",u.nombreUsuario);
    printf("\nPASSWORD: %s",u.pass);
    printf("\nNACIMIENTO: %d",u.anioNacimiento);
    printf("\nGENERO: %c",u.genero);
    printf("\nPAIS: %s",u.pais);
    printf("\nELIMINADO: %d",u.eliminado);
    printf("\n==========");
}


///ID USUARIOS

int GenerarIDUnicoUsuarios(ArbolUsuarios* arbol) ///genera un id unico, revisando un arbol usuarios
{
    int flag=0,id;

        do{
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolU(arbol,id)==0)
        {
            flag=1;
        }
        }while(flag!=1);

    return id;
}


int buscaIDenArbolU (ArbolUsuarios *arbol, int id) ///busca un id en arbol usuarios, retorna un flag
{
    int flag=0;

        if (arbol)
            {
            if (id == arbol->dato.idUsuario)
                {
                    flag=1;
                }
            else
                if (id > arbol->dato.idUsuario)
                    {
                    flag = buscaIDenArbolU(arbol->izq,id);
                    }
                else
                    {
                    flag = buscaIDenArbolU(arbol->der,id);
                    }
            }
    return flag;
}


/// PASAJE A ARCHIVO USUARIOS
 void pasarArchUsuarioToArbol (ArbolUsuarios** arbol)
 { ///Cargar un arbol de un archivo
    FILE *pArchusuarios = fopen(AR_USUARIOS, "rb");
    //stCancion aux;
    stUsuario usuarioAux;
    if (pArchusuarios){
        while (fread(&usuarioAux, sizeof(stUsuario), 1, pArchusuarios)>0){
            //MuestraUnUsuario(usuarioAux);
            agregarUsuario(*(&arbol),usuarioAux);
            //mostrarNodoArbolU(*arbol);
            ///Falta implementar esta parte, agregarle una lista de canciones personal del usuario
            //ArbolCanciones* cons = crearNodoCancion(aux); ///Crea lista doble de playlist.
        }
        fclose(pArchusuarios);
    }
}

/// PASAJE DE CANCIONES FAVORITAS DE USUARIO A ARCHIVO
 void pasarArchivoUsuarioToArbol (ArbolUsuarios** arbol)
 { ///Cargar un arbol de un archivo
    FILE *pArchusuarios = fopen(AR_USUARIOS, "rb");
    stUsuario usuarioAux;
    int idLista;
    if (pArchusuarios){
        while (fread(&usuarioAux, sizeof(stUsuario), 1, pArchusuarios)>0){
            idLista = agregarUsuario(*(&arbol),usuarioAux);
            //mostrarNodoArbolU(*arbol);
        }
        fclose(pArchusuarios);
    }
}

void GuardaUsuarioEnArchivo (ArbolUsuarios *arbol,FILE *pArchusuarios)
{
    if(pArchusuarios)
        {
            if(arbol != NULL)
            {
                fwrite(&arbol->dato, sizeof (stCancion),1,pArchusuarios);
                GuardaUsuarioEnArchivo(arbol->izq,pArchusuarios);
                GuardaUsuarioEnArchivo(arbol->der,pArchusuarios);
                printf("\n cargado exitosa");
            }
            fclose(pArchusuarios);
        }
}


void muestraArchivoUsuario()
{
     FILE *pArchusuarios = fopen(AR_USUARIOS, "rb");
     stUsuario usuarioAux;
     nodoCancion* favoritas;
     if(pArchusuarios)
     {
         while(fread(&usuarioAux, sizeof(stUsuario), 1, pArchusuarios)>0)
         {
            MuestraUnUsuario(usuarioAux);
            //muestraListadobleIterar(favoritas);
         }
         fclose(pArchusuarios);
     }
}


nodoCancion * agregarAlPrincipio(nodoCancion * lista, nodoCancion * nuevoNodo)
{
    nuevoNodo->sig = lista;
    if(lista!=NULL)
    {
        lista->ante=nuevoNodo;
    }
    return nuevoNodo;
}

void agregarCancionAUsuario(nodoCancion* lista,ArbolUsuarios** arbolU)
{
    /*
    ///EN OTRA FUNCION
    //MOSTRAR LISTA DE CANCIONES
    muestraArchivoCancion();
    //PREGUNTAR QUE CANCION QUIERO AGREGAR
    printf("Ingrese el id de la cancion que desea agregar:");
    scanf("%i",&idCancion);
    ///EN ESTA FUNCION
    ArbolCanciones* cancionEncontrada = inicListaC();
    nodoCancion* cancionFavorita = inicNodoC();
    int flag = buscaIDenArbolCanciones(cancion,id);
    if(flag == 0)
    {
        printf("La cancion que desea agregar no existe");
    }
    else
    {
        int encontroUser = buscaIDenArbolU(arbolU,idUsuario)
        if(encontroUser == 0)
        {
            cancionEncontrada = buscarCancion(arbolC,idCancion);
            arbolU.favoritas = crearNodoCancion(cancionEncontrada);
            mostrarNodoArbolU(arbolU);
        }
    }
    */
    /*
     ArbolUsuarios *iterator = *arbolU;

    if (iterator == NULL){
            (*arbolU)->favoritas = crearNodoCancion(arbolC);
            printf("hola estoy en el if");
        }
    else if ((*arbolU)->favoritas->cancion->dato.idCancion > (iterator->favoritas->cancion->dato.idCancion))
        {
            printf("hola estoy en el else");
            return agregarCancionAUsuario(arbolC,&(iterator->der));
        } else {
            return agregarCancionAUsuario(arbolC,&(iterator->izq));
        }
        */
    //nodoCancion* lista = inicNodoC();
    //nodoCancion* nuevoNodo = crearNodoCancion(arbolC);
    //lista = agregarAlPrincipio(lista,nuevoNodo);
    (*arbolU)->favoritas = lista;
    //muestraListadobleIterar(lista);
    //mostrarCancionFavoritaPorUsuario((*arbolU));

   ///ESTO LO HAGO ASI, SI RECIBO LAS COSAS
    ///POR PARAMETRO, SINO SE PUEDE REFACTORIZAR DE OTRA MANERA
    //PASAR ID DE CANCION QUE QUIERO AGREGAR
    //BUSCAR USUARIO -> EL USUARIO ACA TENDRIA QUE VENIR DESDE EL MENU, PERO SINO LO BUSCO Y PASO POR PARAMETRO
    //EXISTE? AGREGO CANCION QUE PASO ID
    //LA AGREGO COMO ARBOL

    ///HACER VALIDACION PARA VER SI YA AGREGO LA FUNCION O NO (VER COMO TENER EL FLAG SETEADO)
}

ArbolUsuarios* buscarUsuario(ArbolUsuarios *arbol, int id)
{
    ArbolUsuarios* usuarioEncontrado = NULL;

    if(arbol != NULL)
    {
        if(arbol->dato.idUsuario == id)
        {
            usuarioEncontrado = arbol;
        }
        else if(arbol->dato.idUsuario<id)
            usuarioEncontrado = buscarUsuario(arbol->der,id);
        else
            usuarioEncontrado = buscarUsuario(arbol->izq,id);
    }
    return usuarioEncontrado;
}


///TODO PROBAR
void pasarArchivoCancionesFavoritasToArbol(ArbolUsuarios** arbol)
{
    FILE *pArchivoCanciones = fopen(AR_CANCIONES, "rb");
    FILE *pArchivoUsuarios = fopen(AR_USUARIOS, "rb");
    stCancion cancionAux;
    stUsuario usuario;
    int idLista;
    if(pArchivoCanciones && pArchivoUsuarios)
    {
        while(fread(&cancionAux, sizeof(stCancion), 1, pArchivoCanciones)>0 && fread(&usuario, sizeof(stUsuario), 1, pArchivoUsuarios)>0)
        {
            idLista = agregarUsuario(*(&arbol),usuario);
            nodoCancion* nuevoNodo = crearNodoCancionFavorita(cancionAux,idLista);
            (*arbol)->favoritas = agregarAlPrincipio((*arbol)->favoritas,nuevoNodo);
            printf("MUESTRA NODO FAVORITAS");
            MuestraUnUsuario((*arbol)->dato);
            mostrarNodoLista((*arbol)->favoritas);
        }
        fclose(pArchivoCanciones);
        fclose(pArchivoUsuarios);
    }
}




///CARGA RND USUARIOS

stUsuario cargaUsuarioRandom()
{
    stUsuario u;

    u.idUsuario=0;
    getNombresRand(u.nombreUsuario);
    getPassRand(u.pass);
    u.anioNacimiento=getNumRand;
    u.genero='v';
    getPaisRand(u.pais);
    u.eliminado=0;
    u.tipoUsuario=0;

    return u;
}

void getNombresRand(char nya[])
{
    char n[30];
    char nombres [][30] = {"Pedro", "Pablo", "Pilar", "Lucas","Micaela", "Adrian","Lucia","Jeremias","Belen",
                           "Milagros","Tomas","Martin","Sergio","Victoria","Andrea","Luciano","Romina","Franco","Valentina","Melanie",
                           "Guadalupe","Manuel","Carlos","Andrea","Sebastian","Antonio","John","Rocio"
                          };
    strcpy (n, nombres[rand()%(sizeof(nombres)/30)]);

    char a[30];
    char apellidos [][30] = {"Lopez","Fernandez","Acu�a","Martinez","Botero","Verstappen","Alonso","Perez","Leclerc",
                             "Sainz","Norris","Gasly","Vettel","Ricciardo","Senna","Reutemann","Fangio","Barrichello","Hamilton","Trulli","Mansell",
                             "McLaren","Benz","Martin","Williams","Haas","Martinez","Fernandez","Echeverria","Navarro",
                            };
    strcpy (a, apellidos[rand()%(sizeof(apellidos)/30)]);
    sprintf(nya,"%s %s",n,a);

}

void getPassRand(char n[])
{
    char pass [][30] = {"asdasd", "Pazczxblo", "zxczxadwq", "qqwewqe","cvbcvb", "tytyerwer","qweqwe","sdfsdfsd","ncvnbvn",
                           "qweqwe","ertert","tyuty","xcvvxcv","asdas","punbvn","sdfger","asdqwe123","4534zdfx","6436cvx","123124zxc",
                           "zxczxvxc34634","123123zxdc","asdasd23565","hjghjdf421","dsad1325t34","asdaswd123","hjklh213","klkl345"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

int getNumRand()
{
    srand(time(NULL));
    int num= rand() % 100000;
    return num;
}

void getPaisRand(char n[])
{
    char pais [][30] = {"Argentina", "Brasil", "Peru", "Chile","Inglaterra", "Suecia","Holanda","Suiza","Hong Kong",
                           "Paraguay","Francia","Alemania","Portugal","Indonesia","Tunez","Siria","Israel","Estados Unidos","Uruguay","Argelia",
                           "Australia","Nueva Zelanda","Canada","Arabia Saudita","Iran","Mexico","Rusia","Ucrania"
                          };
    strcpy (n, pais[rand()%(sizeof(pais)/30)]);
}
