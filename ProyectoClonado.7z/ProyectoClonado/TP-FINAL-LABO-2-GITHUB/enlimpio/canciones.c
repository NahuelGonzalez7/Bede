#include "canciones.h"
#include "usuarios.h"

///ARBOL CANCIONES

ArbolCanciones* inicListaC() ///CREAR CANCION Y AGREGARLA AL ARBOL
{
    return NULL;
}

ArbolCanciones* crearNodoArbolCancion (stCancion dato) ///CREO NODO PARA EL ARBOL
{
    ArbolCanciones* aux = (ArbolCanciones*) malloc(sizeof(ArbolCanciones));
    aux->dato = dato;
    aux->der = NULL;
    aux->izq = NULL;

    return aux;
}

void AgregarCancion(ArbolCanciones** arbol, stCancion dato) ///AGREGO CANCION AL ARBOL
{
    ArbolCanciones *iterator = *arbol;

    if (iterator == NULL)
    {
        (*arbol) = crearNodoArbolCancion(dato);
        if((*arbol)->dato.idCancion == 0)
        {
            (*arbol)->dato.idCancion = GenerarIDUnicoCanciones(iterator);
        }
    }
    else if (dato.idCancion > (iterator->dato.idCancion))
    {
        return AgregarCancion(&(iterator->der), dato);
    }
    else
    {
        return AgregarCancion(&(iterator->izq), dato);
    }
}

///BUSCAR EN ARBOL
ArbolCanciones* buscarCancion(ArbolCanciones *arbol, int id)
{
    ArbolCanciones* cancionEncontrada = NULL;

    if(arbol != NULL)
    {
        if(arbol->dato.idCancion == id)
        {
            cancionEncontrada = arbol;
        }
        else if(arbol->dato.idCancion<id)
            cancionEncontrada = buscarCancion(arbol->der,id);
        else
            cancionEncontrada = buscarCancion(arbol->izq,id);
    }
    return cancionEncontrada;
}

///PROBAR PARA QUE FUNCIONA
ArbolCanciones* validarCancionEncontrada(ArbolCanciones* arbolCancion)
{
    if(arbolCancion == NULL)
    {
        printf("No existe el arbol de canciones buscado. \n");
    }
    return arbolCancion;
}




/// MOSTRAR ARBOLES
void preorderCancion (ArbolCanciones* arbol) ///MOSTRAR ARBOL
{
    if(arbol!=NULL)
    {
        mostrarNodoArbolCancion(arbol);
        preorderCancion(arbol->izq);
        preorderCancion(arbol->der);
    }
}

void inorderCancion(ArbolCanciones* arbol)
{
    if(arbol!= NULL)
    {
        preorderCancion(arbol->izq);
        mostrarNodoArbolCancion(arbol);
        preorderCancion(arbol->der);
    }
}

void mostrarNodoArbolCancion(ArbolCanciones *arbol)
{
    if(arbol)
    {
        MuestraUnaCancion(arbol->dato);
    }
}














///NODO LISTA DE CANCIONES

nodoCancion* inicNodoC()
{
    return NULL;
}

nodoCancion* crearNodoCancion(ArbolCanciones* dato)
{
    nodoCancion* aux= (nodoCancion*) malloc(sizeof(nodoCancion));
    aux->cancion=dato->dato;
    aux->ante=NULL;
    aux->sig=NULL;

    return aux;
}

nodoCancion* crearNodoListaCancion(stCancion cancion)
{
    nodoCancion* aux= (nodoCancion*) malloc(sizeof(nodoCancion));
    aux->cancion=cancion;
    aux->ante=NULL;
    aux->sig=NULL;

    return aux;
}

nodoCancion* crearNodoCancionFavorita(stCancion cancion,int id)
{
    nodoCancion* aux= (nodoCancion*) malloc(sizeof(nodoCancion));
    aux->cancion = cancion;
    aux->id = id;
    aux->ante=NULL;
    aux->sig=NULL;

    return aux;
}

nodo2 * insertarNodo(nodo2 * lista, nodo2 * nuevoNodo)
{
    if(lista==NULL)
    {
        lista=nuevoNodo;
    }
    else if (nuevoNodo->dato< lista->dato)
    {
        lista=agregarAlPrincipio(lista, nuevoNodo);
    }
    else
    {

        nodo2 * anterior=lista;
        nodo2 * seg=lista->ste;

        while(seg!=NULL && seg->dato < nuevoNodo->dato)
        {
            anterior=seg;
            seg=seg->ste;
        }

        anterior->ste =nuevoNodo;

        nuevoNodo->ante = anterior;
        nuevoNodo->ste=seg;

        if(seg!=NULL)
        {
            seg->ante= nuevoNodo;
        }
    }
    return lista;
}

nodo2 * borrarNodo(nodo2 * lista, int dato)
{
    nodo2 * aBorrar=NULL;
    nodo2 * seg=NULL;

    if(lista!=NULL)
    {
        if(lista->dato==dato)
        {
            aBorrar=lista;

            lista=lista->ste;
            if(lista!=NULL)
                lista->ante=NULL;

            free(aBorrar);
        }
        else
        {
            seg=lista->ste;
            while(seg!=NULL && seg->dato!=dato)
            {
                seg=seg->ste;
            }

            if( seg!= NULL)
            {
                nodo2 * anterior=seg->ante; // bajo a una variable el anterior

                anterior->ste = seg->ste; //salteo el nodo que quiero eliminar.

                if(seg->ste) // si existe el nodo siguiente
                {
                    nodo2 * siguiente = seg->ste;
                    siguiente->ante=anterior;
                }
                free(seg); //elimino el nodo.
            }

        }
    }

    return lista;

}

///TODO->PROBAR

nodoCancion * agregarAlPrincipio(nodoCancion * lista, stCancion cancion)
{
    nodoCancion* nuevoNodo = crearNodoCancion(ArbolCanciones->dato);
    nuevoNodo->ste=lista;
    if(lista!=NULL)
    {
        lista->ante=nuevoNodo;
    }
    return nuevoNodo;
}
//estaba en el otro proyecto, chequear cual funciona
nodoCancion* agregarAlPrincipio(nodoCancion* listaCanciones,stCancion cancion)
{
    nodoCancion* nuevoCancion = crearNodoCancion(ArbolCanciones->dato); //ESTO ESTA RARO
    if(listaCanciones == NULL)
    {
        listaCanciones = nuevoCancion;
    }
    else
    {
        nuevoCancion->siguiente = listaCanciones;
        listaCanciones = nuevoCancion;
    }
    return listaCanciones;
}



// recursivo
///TODO -> PROBAR
nodoCancion * buscarUltimaCancionRecursiva(nodoCancion * lista)
{
    nodoCancion * rta=NULL;
    if(lista!=NULL)
    {
        if(lista->sig==NULL)
        {
            rta=lista;
        }
        else
        {
            rta=buscarUltimaCancionRecursiva(lista->sig);
        }
    }
    return rta;
}
///TODO-> PROBAR
nodoCancion * agregarAlFinal(nodoCancion * lista, nodoCancion * nuevoNodo)
{
    if(lista==NULL)
    {
        lista=nuevoNodo;
    }
    else
    {
        nodoCancion * ultimo = buscarUltimaCancionRecursiva(lista);
        ultimo->sig = nuevoNodo;
        nuevoNodo->ante = ultimo;
    }
    return lista;
}

///TODO -> PROBAR
agregarEnOrdenPorNombreDeCancion()





///DUDABLE FUNCIONAMIENTO, PROBAR DESPUES
void *AgregarNodo(nodoCancion** lista, ArbolCanciones *arbol,int id)///Recibe lista a donde guardar, arbol donde buscar e id de cancion que agregar.
{
    ArbolCanciones *iterator= inicListaC();
    nodoCancion *dato=inicNodoC();
    BuscaCancionXID(&dato,arbol,id);

    if((*lista)==NULL)
    {
        (*lista) = dato;

    }
    else
    {
        AgregarNodo(&(*lista)->sig,arbol,id);
    }
}

/// BUSCA EN UNA LISTA DE CANCIONES POR ID
nodoCancion* buscarCancionesFavoritas(nodoCancion* lista,int id)
{
    nodoCancion* cancionEncontrada = NULL;
    if(lista != NULL)
    {
        if(lista->id == id)
        {
            cancionEncontrada = lista;
        }
        else
        {
            while((cancionEncontrada != NULL) && cancionEncontrada->id != id)
            {
                cancionEncontrada=cancionEncontrada->sig;
            }
        }
    }
    return cancionEncontrada;
}

///PROBAR ESTO
nodoCancion * borrarNodoCancion(nodoCancion * lista, int id)
{
    nodo * aBorrar =NULL;

    if(lista!=NULL)
    {
        if(lista->id==id)
        {
            aBorrar=lista;
            lista=lista->siguiente;
            free(aBorrar);
        }
        else
        {
            lista->siguiente=borrarNodoCancion(lista->siguiente,id);
        }
    }
    return lista;
}



///LISTA DE CANCIONES FAVORITAS -> TEST :)
///TODO PROBAR
/// MUESTRA EL ARCHIVO DE CANCIONES
void mostrarCancionFavoritaArchivo()
{
    FILE *pArchCanciones = fopen(AR_CANCIONES, "r");
    stCancion cancion;
    if(pArchCanciones)
    {
        while(fread(&cancion,sizeof(stCancion),1,pArchCanciones)>0)
        {
            MuestraUnaCancion(cancion);
        }
        fclose(pArchCanciones);
    }
}

///TODO PROBAR
///MUESTRA DESDE UNA LISTA DE CANCIONES FAVORITAS -> NO FUNCIONABA
void muestraArchivoCancionFavorita()
{
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    nodoCancion* lista;
    ArbolCanciones* arbol;
    if(pArchCanciones)
    {
        while(fread(&lista->cancion, sizeof(ArbolCanciones), 1, pArchCanciones)>0)
        {
           mostrarNodoArbolCancion(arbol);
        }
        fclose(pArchCanciones);
    }
}

///TODO REVISAR
///TODO PROBAR
void pasarListaToArchivo(nodoCancion* lista, FILE* pArchivoCanciones)
{
    nodoCancion* iterador = lista;
    if(pArchivoCanciones)
    {
        while(iterador!= NULL)
        {
            fwrite(&iterador->cancion,sizeof(stCancion),1,pArchivoCanciones);
            printf("carga exitosa \n");
            iterador=iterador->sig;
            fclose(pArchivoCanciones);
        }
    }
}

///ESTO FUNCIONA CON UNA LISTA DE ARBOLES
///TODO PROBAR -> NO ESTABA FUNCIONANDO
void guardarCancionFavoritaEnArchivo (nodoCancion* lista,FILE *pArchCanciones)
{
    nodoCancion* iterador = lista;
    if(pArchCanciones)
    {
        while(iterador != NULL)
        {
            fwrite(&lista->cancion,sizeof(ArbolCanciones),1,pArchCanciones);
            printf("carga exitosa");
            iterador=iterador->sig;
            fclose(pArchCanciones);
        }
    }
}








///MUESTRA LISTA
void mostrarNodoLista(nodoCancion* nuevoNodo)
{
    MuestraUnaCancion(nuevoNodo->cancion);
}

void MuestraListaDoble(nodoCancion* lista)
{
    if(lista!=NULL)
    {
        mostrarNodoLista(lista);
        MuestraListaDoble(lista->sig);
    }
}

///TODO BORRAR
void muestraListadobleIterar(nodoCancion* lista)
{
    nodoCancion * seg = lista;
    while (seg != NULL)
    {
        printf("\n ID LISTA: %d\n",seg->id);
        mostrarNodoLista(seg);
        seg = seg->sig;
    }
}






///MUESTRA UNA CANCION
void MuestraUnaCancion(stCancion cancion) ///MUESTRA UNA CANCION
{
    printf("\n=======================");
    printf("\n ID: %d .",cancion.idCancion);
    printf("\n Artista: %s",cancion.artista);
    printf("\n Titulo: %s",cancion.titulo);
    printf("\n Duracion: %d s",cancion.duracion);
    printf("\n Album: %s .",cancion.album);
    printf("\n Fecha: %d.",cancion.anio);
    printf("\n Genero: %s ",cancion.genero);
    printf("\n Comentario: %s ",cancion.comentario);
    printf("\n Status: %d",cancion.eliminado);
    printf("\n=======================");
}






///ID CANCIONES
int GenerarIDUnicoCanciones(ArbolCanciones* arbol) ///genera un id unico, revisando un arbol dado
{
    int flag=0,id;

    do
    {
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolCanciones(arbol,id)==0)
        {
            flag=1;
        }
    }
    while(flag!=1);

    return id;
}

int buscaIDenArbolCanciones (ArbolCanciones *arbol, int id) ///busca un id en arbol canciones, retorna un flag
{
    int flag=0;

    if (arbol)
    {
        if (id == arbol->dato.idCancion)
        {
            flag=1;
        }
        else if (id > arbol->dato.idCancion)
        {
            flag = buscaIDenArbolCanciones(arbol->izq,id);
        }
        else
        {
            flag = buscaIDenArbolCanciones(arbol->der,id);
        }
    }
    return flag;
}






///ARCHIVOS CANCIONES

///TODO PROBAR
void muestraArchivoCancion() //MUESTRA LAS CANCIONES CARGADAS EN EL ARCHIVO DE CANCIONES
{
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion cancionesAux;
    if(pArchCanciones)
    {
        while(fread(&cancionesAux, sizeof(stCancion), 1, pArchCanciones)>0)
        {
            MuestraUnaCancion(cancionesAux);
        }
        fclose(pArchCanciones);
    }
}

///Carga un arbol de canciones desde un archivo de canciones
///TODO PROBAR
void pasarArchCancionToArbol (ArbolCanciones** arbol)
{
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion cancionAux;
    if (pArchCanciones)
    {
        while (fread(&cancionAux, sizeof(stCancion), 1, pArchCanciones)>0)
        {
            AgregarCancion(*(&arbol),cancionAux);
            sleep(1);
        }
        fclose(pArchCanciones);
    }
}

///Guarda una cancion en el archivo a partir de un Arbol de canciones
///TODO PROBAR
void GuardaCancionEnArchivo (ArbolCanciones *arbol,FILE *pArchCanciones)
{
    if(pArchCanciones)
    {
        if(arbol != NULL)
        {
            fwrite(&arbol->dato, sizeof (stCancion),1,pArchCanciones);
            GuardaCancionEnArchivo(arbol->izq,pArchCanciones);
            GuardaCancionEnArchivo(arbol->der,pArchCanciones);
            fclose(pArchCanciones);
            printf("\n carga exitosa");
        }
    }
}


///ALTA CANCION
stCancion cargarCancion(stCancion cancion){
    printf("REGISTRO DE CANCION\n\n");

    printf("INGRESE TITULO DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.titulo);

    printf("\nINGRESE EL ARTISTA DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.artista);

    printf("\nINGRESE LA DURACION DE LA CANCION: ");
    fflush(stdin);
    scanf("%i", &cancion.duracion);

    printf("\nINGRESE EL ALBUM DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.album);

    printf("\nINGRESE EL ANIO DE LA CANCION: ");
    fflush(stdin);
    scanf("%i", &cancion.anio);

    printf("\nINGRESE EL GENERO DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.genero);

    printf("\nINGRESE UN COMENTARIO: ");
    fflush(stdin);
    gets(cancion.comentario);

    cancion.eliminado = 0;

    return usuario;
}


///CARGA RND CANCIONES
stCancion cargaCancionRandom()
{
    stCancion c;

    c.idCancion=0;
    getTituloRand(c.titulo);
    getArtistaRand(c.artista);
    c.duracion=getDuracionRand();
    getAlbumRand(c.album);
    c.anio=getAnioRand();
    getGeneroRand(c.genero);
    GetComentarioDefault(c.comentario);
    c.eliminado=0;


    return c;
}

void getTituloRand(char n[])
{
    char pass [][30] = {"Solia", "La Bachata", "La Carretera", "Impala","Loser", "Adore You","Te Amo","Me Gustas Tu","Creo",
                        "Lucky","Yellow","Lo Quiero Todo","Disfruto","Tan Lejos","Traicionero","Nada","Perdido","Fuego","Nunca Quise","Prohibido",
                        "Sorry","Rockstar","Faded","My Way","In My Mind","Alone","Rude","Ride It"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getArtistaRand(char n[])
{
    char pass [][30] = {"Rihanna", "Don Omar", "Makano", "Adele","Sia", "Tiesto","Martin Garrix","Avicci","Calvin Harris",
                        "Dua Lipa","Coldplay","Daddy Yankee","Justin Bieber","Post Malone","Lady Gaga","Sam Smith","Ariana Grande","Callejeros","Duki","Enya",
                        "Moby","Gorillaz","Bad Bunny","Bizarrap","Drake","Porta","Los Piojos","AK"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getAlbumRand(char n[])
{
    char pass [][30] = {"Thriller", "Rumours", "Pet Sounds", "Music Box","One", "Millennium","Baby One More Time","Titanic","Bad",
                        "Nevermind","Metalica","Spice","Grease","Supernatural","Tapestry","Daydream","Romanza","Legend","Believe","Janet",
                        "Whitney","Purple Rain","The Rain","History","Signos","Giros","Oasis","Forth"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getGeneroRand(char n[])
{
    char pass [][30] = {"Trap", "Tango", "Techno", "Jazz","Soul", "Blues","Rock and Roll","Metal","Disco",
                        "Pop","Reggaeton","Country","House","Salsa","Flamenco","Hip Hop","Reggae","Ranchera","Rap","Cumbia",
                        "Bachata","Samba","Kpop","Heavy Metal","Dubstep","Folclore","Lirico","Gospel"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

int getAnioRand()
{
    int nro, min=1950,max=2022;

    srand(time(NULL));
    nro=min+rand()%(max-min);

    return nro;
}

int getDuracionRand()
{
    int nro, min=95,max=300;

    srand(time(NULL));
    nro=min+rand()%(max-min);

    return nro;
}

void GetComentarioDefault(char n[])
{

    char comment[15] = {"no comments"};
    strcpy(n,comment);

}
