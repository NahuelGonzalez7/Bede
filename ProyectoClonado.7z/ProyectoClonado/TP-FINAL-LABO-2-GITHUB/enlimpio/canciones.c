

#include "canciones.h"


///ARBOL CANCIONES

ArbolCanciones* inicListaC()///CREAR CANCION Y AGREGARLA AL ARBOL
{
    return NULL;
}

ArbolCanciones* crearNodoArbolCancion (stCancion dato)
{
    ArbolCanciones* aux = (ArbolCanciones*) malloc(sizeof(ArbolCanciones));

    aux->dato = dato;
    aux->der = NULL;
    aux->izq = NULL;

    return aux;
}

void AgregarCancion(ArbolCanciones** arbol, stCancion dato)
{
    ArbolCanciones *iterator = *arbol;

    if (iterator == NULL)
    {
        (*arbol) = crearNodoArbolCancion(dato);
        if((*arbol)->dato.idCancion == 0)
        {
            (*arbol)->dato.idCancion = GenerarIDUnicoCanciones(iterator);
        }
    }
    else if (dato.idCancion > (iterator->dato.idCancion))
    {
        return AgregarCancion(&(iterator->der), dato);
    }
    else
    {
        return AgregarCancion(&(iterator->izq), dato);
    }
}

///NODO CANCION

nodoCancion* inicNodoC()
{
    return NULL;
}

nodoCancion* crearNodoCancion(ArbolCanciones* dato)
{
    nodoCancion* aux= (nodoCancion*) malloc(sizeof(nodoCancion));
    aux->cancion = dato;
    aux->ante=NULL;
    aux->sig=NULL;

    return aux;
}

void *AgregarNodo(nodoCancion** lista, ArbolCanciones *arbol,int id)///Recibe lista a donde guardar, arbol donde buscar e id de cancion que agregar.
{
    ArbolCanciones *iterator= inicListaC();
    nodoCancion *dato=inicNodoC();
    BuscaCancionXID(&dato,arbol,id);

    if((*lista)==NULL)
    {
        (*lista) = dato;

    }
    else
    {
        AgregarNodo(&(*lista)->sig,arbol,id);
    }
}

///TODO -> PROBAR
/*
nodoCancion * borrarNodo(nodoCancion * lista, int id) {
   nodoCancion * seg;
   nodoCancion * ante; //apunta al nodo anterior que seg.
   nodoCancion * aux = lista;
   ante = lista;
   nodoCancion * desp = lista ->despues;
   if((lista != NULL) && (id == lista->cancion.dato.idCancion )) {
      lista = lista->despues; //salteo el primer nodo.
      free(aux);                //elimino el primer nodo.
   }else {
      seg = lista;
      while((seg != NULL) && (id =! lista->cancion.dato.idCancion)) {
         ante = seg;           //adelanto una posici�n la variable ante.
         desp = desp->despues; //avanzo al siguiente nodo.
      }
      //en este punto tengo en la variable ante la direcci�n de
      //memoria del nodo anterior al buscado, y en la variable seg,
      //la direcci�n de memoria del nodo que quiero borrar.
      if(seg!=NULL) {
         ante->despues = seg->despues;
         //salteo el nodo que quiero eliminar.
         free(seg);
         //elimino el nodo.
      }
   }
   return lista;
}
*/
///MUESTRA CANCIONES

void preorderCancion (ArbolCanciones* arbol)///Mostrar ARBOL
{
    if(arbol!=NULL)
    {
        mostrarNodoArbolCancion(arbol);
        preorderCancion(arbol->izq);
        preorderCancion(arbol->der);
    }
}

void inorderCancion(ArbolCanciones* arbol)
{
    if(arbol!= NULL)
    {
        preorderCancion(arbol->izq);
        mostrarNodoArbolCancion(arbol);
        preorderCancion(arbol->der);
    }
}

void mostrarNodoArbolCancion(ArbolCanciones *arbol)
{
    if(arbol)
    {
        MuestraUnaCancion(arbol->dato);
    }
}

void mostrarNodoLista(nodoCancion* nuevoNodo)
{
    printf("\n CANCION ADENTRO DE NUEVO NODO \n");
    MuestraUnaCancion(nuevoNodo->cancion->dato);
}

void MuestraUnaCancion(stCancion cancion)///MUESTRA UNA CANCION
{
    printf("\n=======================");
    printf("\n ID: %d .",cancion.idCancion);
    printf("\n Artista: %s",cancion.artista);
    printf("\n Titulo: %s",cancion.titulo);
    printf("\n Duracion: %d s",cancion.duracion);
    printf("\n Album: %s .",cancion.album);
    printf("\n Fecha: %d.",cancion.anio);
    printf("\n Genero: %s ",cancion.genero);
    printf("\n Comentario: %s ",cancion.comentario);
    printf("\n Status: %d",cancion.eliminado);
    printf("\n=======================");
}


void MuestraListaDoble(nodoCancion* lista)
{
    if(lista!=NULL)
    {
        mostrarNodoArbolCancion(lista->cancion);
        MuestraListaDoble(lista->sig);
    }
}
void muestraListadobleIterar(nodoCancion* lista)
{
    nodoCancion * seg = lista;
    while (seg != NULL)
    {
        mostrarNodoArbolCancion(seg->cancion);
        seg = seg->sig;
    }
}

///ID CANCIONES
int GenerarIDUnicoCanciones(ArbolCanciones* arbol) ///genera un id unico, revisando un arbol dado
{
    int flag=0,id;

    do
    {
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolCanciones(arbol,id)==0)
        {
            flag=1;
        }
    }
    while(flag!=1);

    return id;
}

int buscaIDenArbolCanciones (ArbolCanciones *arbol, int id) ///busca un id en arbol canciones, retorna un flag
{
    int flag=0;

    if (arbol)
    {
        if (id == arbol->dato.idCancion)
        {
            flag=1;
        }
        else if (id > arbol->dato.idCancion)
        {
            flag = buscaIDenArbolCanciones(arbol->izq,id);
        }
        else
        {
            flag = buscaIDenArbolCanciones(arbol->der,id);
        }
    }
    return flag;
}


ArbolCanciones* buscarCancion(ArbolCanciones *arbol, int id)
{
    ArbolCanciones* cancionEncontrada = NULL;

    if(arbol != NULL)
    {
        if(arbol->dato.idCancion == id)
        {
            cancionEncontrada = arbol;
        }
        else if(arbol->dato.idCancion<id)
            cancionEncontrada = buscarCancion(arbol->der,id);
        else
            cancionEncontrada = buscarCancion(arbol->izq,id);
    }
    return cancionEncontrada;
}

/*
ArbolCanciones* borrarUnNodoArbol(ArbolCanciones *arbol,int id)
{
    arbol* arbolABorrar = NULL;
    if(arbol != NULL)
    {
        arbolABorrar = buscarCancion(arbol,id);

    }

    ///TODO BORRAR ARBOL


}

nodo * borrarNodoR( nodo * lista, int dato)
{
    nodo * aBorrar =NULL;

    if(lista!=NULL)
    {
        if(lista->dato==dato)
        {
            aBorrar=lista;
            lista=lista->siguiente;
            free(aBorrar);
        }
        else
        {
            lista->siguiente=borrarNodoR(lista->siguiente,dato);
        }
    }
    return lista;
}
*/

///ARCHIVO CANCIONES
void muestraArchivoCancion()
{
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion cancionesAux;
    if(pArchCanciones)
    {
        while(fread(&cancionesAux, sizeof(stCancion), 1, pArchCanciones)>0)
        {
            MuestraUnaCancion(cancionesAux);
        }
        fclose(pArchCanciones);
    }
}

void pasarArchCancionToArbol (ArbolCanciones** arbol)
{
    ///Cargar un arbol de un archivo
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion cancionAux;
    if (pArchCanciones)
    {
        while (fread(&cancionAux, sizeof(stCancion), 1, pArchCanciones)>0)
        {
            //MuestraUnUsuario(usuarioAux);
            AgregarCancion(*(&arbol),cancionAux);
            sleep(1);
            ///Falta implementar esta parte, agregarle una lista de canciones personal del usuario
            //ArbolCanciones* cons = crearNodoCancion(aux); ///Crea lista doble de playlist.
        }
        fclose(pArchCanciones);
    }
}

void GuardaCancionEnArchivo (ArbolCanciones *arbol,FILE *pArchCanciones)
{
    if(pArchCanciones)
    {
        if(arbol != NULL)
        {
            fwrite(&arbol->dato, sizeof (stCancion),1,pArchCanciones);
            GuardaCancionEnArchivo(arbol->izq,pArchCanciones);
            GuardaCancionEnArchivo(arbol->der,pArchCanciones);
            fclose(pArchCanciones);
            printf("\n carga exitosa");
        }
    }
}







///CARGA RND CANCIONES
stCancion cargaCancionRandom()
{
    stCancion c;

    c.idCancion=0;
    getTituloRand(c.titulo);
    getArtistaRand(c.artista);
    c.duracion=getDuracionRand();
    getAlbumRand(c.album);
    c.anio=getAnioRand();
    getGeneroRand(c.genero);
    GetComentarioDefault(c.comentario);
    c.eliminado=0;


    return c;
}

void getTituloRand(char n[])
{
    char pass [][30] = {"Solia", "La Bachata", "La Carretera", "Impala","Loser", "Adore You","Te Amo","Me Gustas Tu","Creo",
                        "Lucky","Yellow","Lo Quiero Todo","Disfruto","Tan Lejos","Traicionero","Nada","Perdido","Fuego","Nunca Quise","Prohibido",
                        "Sorry","Rockstar","Faded","My Way","In My Mind","Alone","Rude","Ride It"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getArtistaRand(char n[])
{
    char pass [][30] = {"Rihanna", "Don Omar", "Makano", "Adele","Sia", "Tiesto","Martin Garrix","Avicci","Calvin Harris",
                        "Dua Lipa","Coldplay","Daddy Yankee","Justin Bieber","Post Malone","Lady Gaga","Sam Smith","Ariana Grande","Callejeros","Duki","Enya",
                        "Moby","Gorillaz","Bad Bunny","Bizarrap","Drake","Porta","Los Piojos","AK"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getAlbumRand(char n[])
{
    char pass [][30] = {"Thriller", "Rumours", "Pet Sounds", "Music Box","One", "Millennium","Baby One More Time","Titanic","Bad",
                        "Nevermind","Metalica","Spice","Grease","Supernatural","Tapestry","Daydream","Romanza","Legend","Believe","Janet",
                        "Whitney","Purple Rain","The Rain","History","Signos","Giros","Oasis","Forth"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getGeneroRand(char n[])
{
    char pass [][30] = {"Trap", "Tango", "Techno", "Jazz","Soul", "Blues","Rock and Roll","Metal","Disco",
                        "Pop","Reggaeton","Country","House","Salsa","Flamenco","Hip Hop","Reggae","Ranchera","Rap","Cumbia",
                        "Bachata","Samba","Kpop","Heavy Metal","Dubstep","Folclore","Lirico","Gospel"
                       };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

int getAnioRand()
{
    int nro, min=1950,max=2022;

    srand(time(NULL));
    nro=min+rand()%(max-min);

    return nro;
}

int getDuracionRand()
{
    int nro, min=95,max=300;

    srand(time(NULL));
    nro=min+rand()%(max-min);

    return nro;
}


void GetComentarioDefault(char n[])
{

    char comment[15] = {"no comments"};
    strcpy(n,comment);

}
