#ifndef USUARIOS_H_INCLUDED
#define USUARIOS_H_INCLUDED


#include "canciones.h"
#define AR_CANCIONES "canciones.dat"
#define AR_USUARIOS "usuarios.dat"


typedef struct {
 int idUsuario;
 int tipoUsuario; //indica 0 si es usuario comun, 1 si es admin
 char nombreUsuario[30];
 char pass[20];
 int anioNacimiento;
 char genero;
 char pais[20];
 int eliminado; // indica 1 o 0 si el cliente fue eliminado
} stUsuario;

typedef struct ArbolUsuarios ArbolUsuarios;
 struct ArbolUsuarios{
    stUsuario dato;
    nodoCancion *favoritas;
    ArbolUsuarios *izq;
    ArbolUsuarios *der;
};


///USUARIOS
ArbolUsuarios* inicListaU();
ArbolUsuarios* crearNodoUsuario (stUsuario dato);///no anda
int agregarUsuario (ArbolUsuarios** arbol, stUsuario dato);///no anda
void mostrarNodoArbolU(ArbolUsuarios *arbol);
void preorderU (ArbolUsuarios* arbol);
void inorderU(ArbolUsuarios* arbol);
void MuestraUnUsuario(stUsuario u);
void MuestraUnUsuario(stUsuario u);
void pasarArchUsuarioToArbol (ArbolUsuarios** arbol);
void muestraArchivoCancionesUsuario();

///PASAR DE ARCHIVO A ARBOL
void pasarArchivoCancionesFavoritasToArbol(ArbolUsuarios** usuarios);

///CargaRND
stUsuario cargaUsuarioRandom ();
void getNombresRand(char n[]);
void getPassRand(char n[]);
int getNumRand();
void getPaisRand(char n[]);
void getGeneroRand(char n[]);


#endif // USUARIOS_H_INCLUDED
