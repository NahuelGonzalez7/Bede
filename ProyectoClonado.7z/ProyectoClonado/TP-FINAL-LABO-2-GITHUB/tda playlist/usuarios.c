#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "playlist.h"
#include "usuarios.h"

int main()
{
    stUsuario user;
    ArbolUsuarios arbolU = inicLista();

    for(int i=0;i<10;i++)
    {

    user = cargaUsuarioRandom();
    agregarUsuario(&arbolU,user);
    preorderU(arbolU);
    }

}
///ARBOL USUARIOS

ArbolUsuarios* inicLista()
{
    return NULL;
}

ArbolUsuarios* crearNodoUsuario (stUsuario dato){////no anda
    ArbolUsuarios* aux = (ArbolUsuarios*) malloc(sizeof(ArbolUsuarios));

    aux->dato = dato;
    aux->der = NULL;
    aux->izq = NULL;

    return aux;
}

void agregarUsuario (ArbolUsuarios** arbol, stUsuario dato){////no anda
    if ((arbol*) == NULL){
        arbol = crearNodoUsuario(dato);
    } else if (dato.idUsuario > (arbol*->dato.idUsuario)) {
            (*arbol->der) = agregarUsuario((arbol&)->der, dato);
        } else {
            (*arbol->izq) = agregarUsuario((arbol&)->izq, dato);
        }
}

void mostrarNodoArbolU(ArbolUsuarios *arbol)
{
    if(arbol)
    {
        MuestraUnUsuario(arbol->dato);
    }
}

void preorderU (ArbolUsuarios* arbol){
    if(arbol!=NULL)
        {
            mostrarNodoArbolU(arbol);
            preorder(arbol->izq);
            preorder(arbol->der);
        }
}
void inorderU(ArbolUsuarios* arbol)
{
    if(arbol!= NULL)
    {
        preorder(arbol->izq);
        mostrarNodoArbolU(arbol);
        preorder(arbol->der);
    }
}

int buscaIDenArbolU (ArbolUsuarios* arbol, int id) ///busca un id en un arbol, retorna un flag
{
    int flag;
        ArbolUsuarios *buscador=NULL;
        if (arbol)
            {
            if (id == arbol->dato.idUsuario)
                {
                flag = 1;
                }
            else
                if (id > arbol->dato.idUsuario)
                    {
                    flag = buscaIDenArbolU(arbol->izq,id);
                    }
                else
                    {
                    flag = buscaIDenArbolU(arbol->der,id);
                    }
            }
    return flag;
}







///USUARIOS
/*
stUsuario CargaUnUsuario()
{
    stUsuario u;
    u.idUsuario = 1;
    printf("%s",username);
    strcpy(u.nombreUsuario,username);
    strcpy(u.pass,password);
    u.anioNacimiento = anio;
    strcpy(u.genero,genero);
    strcpy(u.pais,pais);
    u.eliminado = eliminado;

    MuestraUnUsuario(u);
    return u;
}
*/
void MuestraUnUsuario(stUsuario u)
{
    printf("\n==========");
    printf("\nUSER: %d",u.idUsuario);
    printf("\nNOBMRE: %s",u.nombreUsuario);
    printf("\nPASSWORD: %s",u.pass);
    printf("\nNACIMIENTO: %d",u.anioNacimiento);
    printf("\nGENERO: %c",u.genero);
    printf("\nPAIS: %s",u.pais);
    printf("\nELIMINADO: %d",u.eliminado);
    printf("\n==========");
}




///CARGA RND USUARIOS

stUsuario cargaUsuarioRandom()
{
    stUsuario u;

    u.idUsuario=getNumRand;
    getNombresRand(u.nombreUsuario);
    getPassRand(u.pass);
    u.anioNacimiento=getNumRand;
    u.genero='v';
    getPaisRand(u.pais);
    u.eliminado=0;

    return u;
}

void getNombresRand(char nya[])
{
    char n[30];
    char nombres [][30] = {"Pedro", "Pablo", "Pilar", "Lucas","Micaela", "Adrian","Lucia","Jeremias","Belen",
                           "Milagros","Tomas","Martin","Sergio","Victoria","Andrea","Luciano","Romina","Franco","Valentina","Melanie",
                           "Guadalupe","Manuel","Carlos","Andrea","Sebastian","Antonio","John","Rocio"
                          };
    strcpy (n, nombres[rand()%(sizeof(nombres)/30)]);

    char a[30];
    char apellidos [][30] = {"Lopez","Fernandez","Acu�a","Martinez","Botero","Verstappen","Alonso","Perez","Leclerc",
                             "Sainz","Norris","Gasly","Vettel","Ricciardo","Senna","Reutemann","Fangio","Barrichello","Hamilton","Trulli","Mansell",
                             "McLaren","Benz","Martin","Williams","Haas","Martinez","Fernandez","Echeverria","Navarro",
                            };
    strcpy (a, apellidos[rand()%(sizeof(apellidos)/30)]);
    sprintf(nya,"%s %s",n,a);

}

void getPassRand(char n[])
{
    char pass [][30] = {"asdasd", "Pazczxblo", "zxczxadwq", "qqwewqe","cvbcvb", "tytyerwer","qweqwe","sdfsdfsd","ncvnbvn",
                           "qweqwe","ertert","tyuty","xcvvxcv","asdas","punbvn","sdfger","asdqwe123","4534zdfx","6436cvx","123124zxc",
                           "zxczxvxc34634","123123zxdc","asdasd23565","hjghjdf421","dsad1325t34","asdaswd123","hjklh213","klkl345"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

int getNumRand()
{
    srand(time(NULL));
    int num= rand() % 100000;
    return num;
}

void getPaisRand(char n[])
{
    char pais [][30] = {"Argentina", "Brasil", "Peru", "Chile","Inglaterra", "Suecia","Holanda","Suiza","Hong Kong",
                           "Paraguay","Francia","Alemania","Portugal","Indonesia","Tunez","Siria","Israel","Estados Unidos","Uruguay","Argelia",
                           "Australia","Nueva Zelanda","Canada","Arabia Saudita","Iran","Mexico","Rusia","Ucrania"
                          };
    strcpy (n, pais[rand()%(sizeof(pais)/30)]);
}

void getGeneroRand(char n[])
{
    char genero [][30] = {"Pedro", "Pablo", "Pilar", "Lucas","Micaela", "Adrian","Lucia","Jeremias","Belen",
                           "Milagros","Tomas","Martin","Sergio","Victoria","Andrea","Luciano","Romina","Franco","Valentina","Melanie",
                           "Guadalupe","Manuel","Carlos","Andrea","Sebastian","Antonio","Vera","Rocio"
                          };
    strcpy (n, genero[rand()%(sizeof(genero)/30)]);
}




