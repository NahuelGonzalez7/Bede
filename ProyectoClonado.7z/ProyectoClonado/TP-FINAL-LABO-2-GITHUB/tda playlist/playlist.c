#ifndef CANCIONES_H_INCLUDED
#define CANCIONES_H_INCLUDED
#define AR_CANCIONES "canciones.dat"
#include "playlist.h"



int main()
{
    TDAPlaylist lista[10]


    return 0;
}


void CargarTDAPLAYLIST(TDAPlaylist** lista[],int dimension,arbolPadre* arbol)
{




}


