#ifndef PLAYLIST_H_INCLUDED
#define PLAYLIST_H_INCLUDED

typedef struct {
 int idCancion;
 char titulo[30];
 char artista[20];
 int duracion;
 char album[20];
 int anio;
 char genero[20];
 char comentario[100];
 int eliminado; // indica 1 o 0 si la canci�n fue eliminada
} stCancion;

typedef struct {
 int idUsuario;
 char nombreUsuario[30];
 char pass[20];
 int anioNacimiento;
 char genero;
 char pais[20];
 int eliminado; // indica 1 o 0 si el cliente fue eliminado
} stUsuario;




typedef struct ArbolCanciones ArbolCanciones;
struct ArbolCanciones{
    stCancion dato;
    struct ArbolCanciones *izq;
    struct ArbolCanciones *der;
};

typedef struct nodoCancion nodoCancion;
 struct nodoCancion{
    ///LISTAS DE CANCIONES DE UN USUARIO DADO
    ArbolCanciones* cancion;
    nodoCancion* ante;
    nodoCancion* sig;
};

typedef struct ArbolUsuarios ArbolUsuarios;
 struct ArbolUsuarios{
    stUsuario dato;
    nodoCancion *favoritas;
    ArbolUsuarios *izq;
    ArbolUsuarios *der;

};


typedef struct  {
    ArbolCanciones * arbolC;
    ArbolUsuarios * arbolU;
} arbolPadre;

typedef struct {
    ///LISTA DE CANCIONES DE UN GENERO DADO
    char genero;
    nodoCancion* lista

} CancionesXGenero;

typedef struct {
    ///LISTA DE CANCIONES DE UN ARTISTA DADO
    char artista;
    nodoCancion* lista;

} CancionesXArtista;




typedef struct {
    ///ARREGLO DE CANCIONES CON MAS OYENTES
}CancionesTop;



typedef struct {
    nodoCancion* lista;
    char nombreLista[15];
}TDAPlaylist;


///PROTOTIPADOS
int GenerarIDUnico(arbolPadre* arbol); ///genera un id unico, revisando un arbol dado
int buscaIDenArbolC (ArbolCanciones* arbol, int id); ///busca un id en arbol canciones, retorna un flag
int buscaIDenArbolU (ArbolUsuarios* arbol, int id); ///busca un id en un arbol, retorna un flag
int CuentaCancionesPorUsuario(ArbolUsuarios* arbol, int id);///busca cancion por id en las listas favoritos de usuarios, retorna cantidad de veces que la encontro
int RecorreListaCanciones(nodoCancion *lista,int id);///busca un id en un nodocancion, retorna 1 si la encontro
nodoCancion *BuscaCancionXString(ArbolCanciones *arbol,char string,int flag);///busca una cancion por string, si la encuentra devuelve el nodo
void *CargaListaDobleSegunChar(ArbolCanciones *arbol, nodoCancion** lista, char string,int flag);///Carga una lista doble que recibe por parametro, si encuentra coincidencias con el dato recibido(Genero o Artista)
void *CargaListaDobleC(ArbolCanciones* arbol, nodoCancion ** lista,int id); ///Carga una lista doble que recibe por parametro, buscando en un arbol de canciones que recibe por parametro, un ID que recibe por parametro.
int BuscaCancionXStringID(ArbolCanciones *arbol,char string,int flag);///busca una cancion por string, si la encuentra devuelve el ID




#endif // PLAYLIST_H_INCLUDED
