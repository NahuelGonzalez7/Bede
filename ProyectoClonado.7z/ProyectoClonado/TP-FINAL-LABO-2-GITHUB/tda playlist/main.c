#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "playlist.h"

#define AR_CANCIONES "canciones.dat"

///


int main()
{


}


///FUNCIONES DE IDS
int GenerarIDUnicoUsuarios(ArbolUsuarios* arbol) ///genera un id unico, revisando un arbol dado
{
    int flag=0,id;
    do{
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolU(arbol,id)==0)
        {
            flag=1;
        }
    }while(flag!=1);

    return id;
}

int GenerarIDUnicoCancion(ArbolCanciones* arbol) ///genera un id unico, revisando un arbol dado
{
    int flag=0,id;
    do{
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolC(arbol,id)==0)
        {
            flag=1;
        }
    }while(flag!=1);

    return id;
}











void GuardaTDAenArchivo(char archivo[]) ///GUARDA PLAYLISTS EN ARCHIVO
{
FILE*archi=fopen(archivo,"Playlist.dat");
    if(archi)
    {

        fclose(archi);
    }
}

