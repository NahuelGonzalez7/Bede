#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

void menu();
void menuClientes();
void menuAltaCliente();
void menuOrden();
void menuConsumo();
void menuCargaConsumo ();
void menuListarConsumos ();
void menuClienteAModificar ();
void menuConsumosAModificar ();
void menuArbolDeListas ();
void menuLiquidacion();
void lineaHSup ();
void lineaHInf ();




#endif // MENU_H_INCLUDED
