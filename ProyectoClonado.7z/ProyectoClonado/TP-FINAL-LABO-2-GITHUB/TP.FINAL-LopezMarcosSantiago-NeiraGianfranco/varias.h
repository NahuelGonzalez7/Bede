#ifndef VARIAS_H_INCLUDED
#define VARIAS_H_INCLUDED
#include "Cliente.h"
#include "otrasClientes.h"

int randomRango(int min, int max);
int validacFecha(int dia, int mes, int anio);
void getNombre(char n[]);
void getApellido(char a[]);
void getCalle(char c[]);
int getCalleNro();

#endif // VARIAS_H_INCLUDED
