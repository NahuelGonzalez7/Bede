#ifndef USUARIOS_H_INCLUDED
#define USUARIOS_H_INCLUDED

///USUARIOS
ArbolUsuarios* inicLista()
ArbolUsuarios* crearNodoUsuario (stUsuario dato);///no anda
void agregarUsuario (ArbolUsuarios** arbol, stUsuario dato);///no anda
void mostrarNodoArbolU(ArbolUsuarios *arbol);
void preorderU (ArbolUsuarios* arbol);
void inorderU(ArbolUsuarios* arbol);



void MuestraUnUsuario(stUsuario u);

//CargaRND
stUsuario cargaUsuarioRandom ();
void getNombresRand(char n[]);
void getPassRand(char n[]);
int getNumRand();
void getPaisRand(char n[]);
void getGeneroRand(char n[]);


#endif // USUARIOS_H_INCLUDED
