#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "playlist.h"
#include "canciones.h"



int CuentaCancionesPorUsuario(ArbolUsuarios* arbol, int id)///busca cancion por id en las listas favoritos de usuarios, retorna cantidad de veces que la encontro
{
    int contador;

    if(arbol)
    {
        if((RecorreListaCanciones(arbol->favoritas,id))!=0)///si hay coincidencia, se suma uno al contador, y se sigue buscando en los otros nodos
        {
            contador++;
            {
                if(arbol->izq!=NULL)
                {
                    contador+=CuentaCancionesPorUsuario(arbol->izq,id);

                }
                else
                    if(arbol->der!=NULL)
                    {
                        contador+=CuentaCancionesPorUsuario(arbol->der,id);
                    }
            }
        }
        else///si no hay coincidencia, se sigue buscando en los otros nodos
        {
            if(arbol->izq!=NULL)
            {
                contador+=CuentaCancionesPorUsuario(arbol->izq,id);
            }
            else
                {
                    contador+=CuentaCancionesPorUsuario(arbol->der,id);
                }
        }
    }


    return contador;
}

nodoCancion *BuscaCancionXString(ArbolCanciones *arbol,char string,int flag)///busca una cancion por string, si la encuentra devuelve el nodo
{
    nodoCancion *rta=NULL;

    if(arbol)
    {
        if(flag==1)///busca artista
        {
        }
    if(flag==1)
    {
            if(strcmp(string,arbol->dato.artista)==0)
            {
                rta=arbol;
            }
            else
                {
                    rta=BuscaCancionXString(arbol->izq,string,flag);
                    if(rta == NULL)
                    {
                        rta = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return rta;
    }
    if(flag==2)
        {

        if(flag==2)///busca genero
            {
            if(strcmp(string,arbol->dato.genero)==0)
            {
                rta=arbol;
            }
            else
                {
                    rta=BuscaCancionXString(arbol->izq,string,flag);
                    if(rta == NULL)
                    {
                        rta = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return rta;
            }
        }
    }
}

int buscaIDenArbolC (ArbolCanciones* arbol, int id) ///busca un id en arbol canciones, retorna un flag
{
    int flag=0;

        if (arbol)
            {
            if (id == arbol->dato.idCancion)
                {
                    flag=1;
                }
            else
                if (id > arbol->dato.idCancion)
                    {
                    flag = buscaIDenArbolC(arbol->izq,id);
                    }
                else
                    {
                    flag = buscaIDenArbolC(arbol->der,id);
                    }
            }
    return flag;
}

void *CargaListaDobleSegunChar(ArbolCanciones *arbol, nodoCancion** lista, char string,int flag)///Carga una lista doble que recibe por parametro, si encuentra coincidencias con el dato recibido(Genero o Artista)
{

    if(flag==1)///busca artista
    {

    }
    if(flag==2)///busca genero
    {

    }


}

void *CargaListaDobleC(ArbolCanciones* arbol, nodoCancion ** lista,int id) ///Carga una lista doble que recibe por parametro, buscando en un arbol de canciones que recibe por parametro, con un ID que recibe por parametro.
{




}

int BuscaCancionXStringID(ArbolCanciones *arbol,char string,int flag)///busca una cancion por string, si la encuentra devuelve el ID
{
    ArbolCanciones *rta=NULL;
    if(arbol)
    {
        if(flag==1)///busca artista
        {
            if(strcmp(string,arbol->dato.artista)==0)
            {
                rta=arbol->dato.idCancion;
            }
            else
                {
                    rta=BuscaCancionXString(arbol->izq,string,flag);
                    if(rta == NULL)
                    {
                        rta = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return rta;
        }

        if(flag==2)///busca genero
        {
            if(strcmp(string,arbol->dato.genero)==0)
            {
                rta=arbol->dato.idCancion;
            }
            else
                {
                    rta=BuscaCancionXString(arbol->izq,string,flag);
                    if(rta == NULL)
                    {
                        rta = BuscaCancionXString(arbol->der,string,flag);
                    }
                }
        return rta;
        }

    }
}


nodoCancion* borrarCancionXID(nodoCancion* lista, int idCancion)
{
    nodoCancion* seg;
    nodoCancion* ante;
    if(lista && lista->cancion->dato.idCancion == idCancion){
        nodoCancion* aux=lista;
        lista=lista->sig;
        aux->cancion->dato.eliminado = 1; ///La canci�n se elimina
    }else{
        seg = lista;
        while(seg && seg->cancion->dato.idCancion != idCancion){
            ante = seg;
            seg = seg->sig;
        }
        if(seg){
            ante->sig=seg->sig;
            seg->cancion->dato.eliminado = 1; ///La canci�n se elimina
        }
    }
    return lista;
}


int RecorreListaCanciones(nodoCancion *lista,int id)///busca un id en un nodocancion, retorna 1 si la encontro
{
    int flag=0;
    if (lista)
    {
        if (id==lista->cancion->dato.idCancion)
        {
            flag=1;
        }
        else
        {
            if(lista->sig!=NULL)
            {
                flag=RecorreListaCanciones(lista->sig,id);
            }
        }
    }
    return flag;
}










///ARCHIVOS
 ArbolCanciones* pasarArchCancionToArbol (ArbolCanciones* arbol){ ///Cargar un arbol de un archivo
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion aux;
    stCliente clienteAux;
    if (pArchCanciones){
        while (fread(&aux, sizeof(stCancion), 1, pArchCanciones)>0){
            ///clienteAux = buscaUnClientePorID(aux.idCliente); esto no sirve en esta funcion
            ArbolCanciones* cons = crearNodoCancion(aux); ///falta hacer la funcion
            arbol = agregarCancion(arbol, cons); ///FUNCION QUE ENLAZA NUEVO NODO A UN ARBOL
        }
        fclose(pArchCanciones);
    }
    return arbol;
}

void GuardaCancionEnArchivo (ArbolCanciones *arbol)
{
    FILE *parchCanciones = fopen(AR_CANCIONES,"ab");
    if(parchCanciones)
        {
        fwrite(&arbol->dato, sizeof (stCancion),1,parchCanciones);
        fclose(parchCanciones);
        }
}

//////////////////////PUEDE SERVIR

ArbolCanciones * crearNodoCancion(stCancion dato) ///Faltaria agregar puntero doble
{
    ArbolCanciones* nuevo = (ArbolCanciones*)malloc(sizeof(ArbolCanciones));
    nuevo->dato = dato;
    nuevo->der = NULL;
    nuevo->izq = NULL;
    return nuevo;
}


void agregarCancion (ArbolCanciones** arbol, stCancion dato){////no anda
    if ((arbol*) == NULL){
        arbol = crearNodoCancion(dato);
        ///FALTA DEVOLVER AL ARBOL EL OUTPUT
    } else if (dato.idCancion > (arbol*)->dato.idCancion)) {
            (*arbol->der) = agregarCancion((arbol&->der), dato);
        } else {
            (*arbol->izq) = agregarCancion((arbol&->izq), dato);
        }
}


