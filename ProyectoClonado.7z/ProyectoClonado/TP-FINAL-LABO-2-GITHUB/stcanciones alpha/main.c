#include <stdio.h>
#include <stdlib.h>


///Estructura de Canci�n
typedef struct {
 int idCancion;
 char titulo[30];
 char artista[20];
 int duracion;
 char album[20];
 int anio;
 char genero[20];
 char comentario[100];
 int eliminado; // indica 1 o 0 si la canci�n fue eliminada
} stCancion;

typedef struct
{
 stCancion c;
 struct nodoListaCancion * sig;
} nodoListaCancion;

stCancion CargaUnaCancion();
void MuestraUnaCancion(stCancion c);
nodoListaCancion *inicLista();
nodoListaCancion *crearNodoLista (stCancion c);
nodoListaCancion *agregarAlPrincipio(nodoListaCancion *lista, nodoListaCancion *nuevoNodo);
void mostrarLista(nodoListaCancion *lista);
nodoListaCancion *BuscaNodoPorID(nodoListaCancion* lista, int id);



int main()
{
    ///stCancion c=CargaUnaCancion();
    ///MuestraUnaCancion(c);
    nodoListaCancion* c=inicLista();
    agregarAlPrincipio(c,crearNodoLista(CargaUnaCancion));


    return 0;
}


stCancion CargaUnaCancion()/*PASARLO POR REF*/
{
    stCancion c;
    printf("\nIngrese el nombre del artista: ");
    fflush(stdin);
    gets(c.artista);
    printf("\nIngrese el titulo de la cancion: ");
    fflush(stdin);
    gets(c.titulo);
    printf("\nIngrese duracion de la cancion en segundos: ");
    fflush(stdin);
    scanf("%d",&c.duracion);
    printf("\nIngrese el nombre del album al que pertenece: ");
    fflush(stdin);
    gets(c.album);
    printf("\nIngrese el anio de la cancion: ");
    fflush(stdin);
    scanf("%d",&c.anio);
    printf("\nIngrese el genero de la cancion: ");
    fflush(stdin);
    gets(c.genero);
    printf("\nIngrese un comentario: ");
    fflush(stdin);
    gets(c.comentario);
    c.eliminado=1;
    c.idCancion=1;

    return c;
}

void MuestraUnaCancion(stCancion c)
{
    printf("\n=======================");
    printf("\nArtista: %s",c.artista);
    printf("\nTitulo: %s",c.titulo);
    printf("\nDuracion: %d s",c.duracion);
    printf("\nAlbum: %s .",c.album);
    printf("\nFecha: %d.",c.anio);
    printf("\nGenero: %s ",c.genero);
    printf("\nComentario: %s ",c.comentario);
    printf("\nID: %d .",c.idCancion);
    printf("\nStatus: %d",c.eliminado);
    printf("\n=======================");
}

nodoListaCancion *inicLista()
{
    return NULL;
}

nodoListaCancion *crearNodoLista (stCancion c)
{
    nodoListaCancion * aux= (nodoListaCancion*) malloc(sizeof(nodoListaCancion));
    aux->c;
    aux->sig= NULL;
    return aux;
}

nodoListaCancion *agregarAlPrincipio(nodoListaCancion *lista, nodoListaCancion *nuevoNodo)
{
    if(lista == NULL)
    {
        lista= nuevoNodo;
    }
    else
    {
        nuevoNodo->sig = lista;
        lista=nuevoNodo;
    }
    return lista;
}

agregarEnOrdenPorNombreDeCancion(nodoListaCancion*lista, nodoListaCancion *nuevoNodo)
{

}

void mostrarLista(nodoListaCancion *lista)
{
    nodoListaCancion *mostrar=lista;
    while(mostrar!=NULL)
    {
        MuestraUnaCancion(mostrar->c);
    }

}

nodoListaCancion *borrarNodoPorIdCancion(nodoListaCancion *lista,int dato)
{
    nodoListaCancion *eliminar=lista;
    while(lista!=NULL)
    {
        BuscaNodoPorID(lista,dato);
    } ///no anda jeje

}

nodoListaCancion *BuscaNodoPorID(nodoListaCancion* lista, int id)
{
    nodoListaCancion *buscar=lista;
    if(lista!=NULL)
    {
        while((buscar!=NULL) && (id!=buscar->c.idCancion))
        {
            buscar=buscar->sig;
        }
    }
    return buscar;
}
