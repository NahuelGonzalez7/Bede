#include <stdio.h>
#include <stdlib.h>

#define AR_CANCIONES "canciones.dat"


typedef struct {
 int idCancion;
 char titulo[30];
 char artista[20];
 int duracion;
 char album[20];
 int anio;
 char genero[20];
 char comentario[100];
 int eliminado; // indica 1 o 0 si la canci�n fue eliminada
} stCancion;

typedef struct ArbolCanciones ArbolCanciones;
struct ArbolCanciones{
    stCancion dato;
    struct ArbolCanciones *izq;
    struct ArbolCanciones *der;
};

typedef struct nodoCancion nodoCancion;
 struct nodoCancion{
    ///LISTAS DE CANCIONES
    ArbolCanciones* cancion;
    nodoCancion* ante;
    nodoCancion* sig;
};


///CANCIONES
ArbolCanciones* inicLista();
ArbolCanciones* crearNodoArbolCancion (stCancion dato);
void AgregarCancion(ArbolCanciones** arbol, stCancion dato);
void mostrarNodoArbolCancion(ArbolCanciones *arbol);
void preorderCancion (ArbolCanciones* arbol);
void inorderCancion(ArbolCanciones* arbol);
void MuestraUnaCancion(stCancion cancion);
int GenerarIDUnicoCanciones(ArbolCanciones* arbol);
int buscaIDenArbolCanciones (ArbolCanciones *arbol, int id);
void pasarArchUsuarioToArbol (ArbolCanciones** arbol);
void GuardaCancionEnArchivo (ArbolCanciones *arbol,FILE *pArchCanciones);
void muestraArchivoCancion();

///CARGA RND
stCancion cargaCancionRandom();
void getTituloRand(char n[]);
void getArtistaRand(char n[]);
void getAlbumRand(char n[]);
void getGeneroRand(char n[]);
int getAnioRand();
int getDuracionRand();

int main()
{
    stCancion cancion;
    ArbolCanciones *arbolCancion = inicLista();
    ArbolCanciones *arbolCancionAux = inicLista();

    ///FUNCIONA OK
    /*
    for(int i=0;i<10;i++)
    {
        cancion = cargaCancionRandom();
        AgregarCancion(&arbolCancion,cancion);
        sleep(1);
    }
    preorderCancion(arbolCancion);
    FILE *pArchCanciones = fopen(AR_CANCIONES,"ab");
    GuardaCancionEnArchivo(arbolCancion,pArchCanciones);
    muestraArchivoCancion();
    */
    pasarArchUsuarioToArbol(&arbolCancionAux);
    printf("\n archivo cargado");
    mostrarNodoArbolCancion(&arbolCancionAux);
}


///CREAR CANCION Y AGREGARLA AL ARBOL
ArbolCanciones* inicLista()
{
    return NULL;
}

ArbolCanciones* crearNodoArbolCancion (stCancion dato){
    ArbolCanciones* aux = (ArbolCanciones*) malloc(sizeof(ArbolCanciones));

    aux->dato = dato;
    aux->der = NULL;
    aux->izq = NULL;

    return aux;
}

void AgregarCancion(ArbolCanciones** arbol, stCancion dato)
{
    ArbolCanciones *iterator = *arbol;

    if (iterator == NULL){
        (*arbol) = crearNodoArbolCancion(dato);
            if((*arbol)->dato.idCancion == 0)
             {
                 (*arbol)->dato.idCancion = GenerarIDUnicoCanciones(iterator);
             }
        }
        else if (dato.idCancion > (iterator->dato.idCancion))
        {
            return AgregarCancion(&(iterator->der), dato);
        } else {
            return AgregarCancion(&(iterator->izq), dato);
        }
}


///MUESTRA
///Mostrar LISTA
/*
void mostrarNodo(nodoListaCancion * nodoActual)
{
    MuestraUnaCancion(&nodoActual->cancion);
}
void mostrarLista(nodoListaCancion *lista)
{
        nodoListaCancion* iterador = lista;
        while(iterador != NULL)
        {
            mostrarNodo(iterador);
            iterador = iterador->siguiente;
        }
}
*/
///Mostrar ARBOL
void preorderCancion (ArbolCanciones* arbol){
    if(arbol!=NULL)
        {
            mostrarNodoArbolCancion(arbol);
            preorderCancion(arbol->izq);
            preorderCancion(arbol->der);
        }
}

void inorderCancion(ArbolCanciones* arbol)
{
    if(arbol!= NULL)
    {
        preorderCancion(arbol->izq);
        mostrarNodoArbolCancion(arbol);
        preorderCancion(arbol->der);
    }
}

void mostrarNodoArbolCancion(ArbolCanciones *arbol)
{
    if(arbol)
    {
        MuestraUnaCancion(arbol->dato);
    }
}

///MUESTRA UNA CANCION
void MuestraUnaCancion(stCancion cancion)
{
    printf("\n=======================");
    printf("\n ID: %d .",cancion.idCancion);
    printf("\n Artista: %s",cancion.artista);
    printf("\n Titulo: %s",cancion.titulo);
    printf("\n Duracion: %d s",cancion.duracion);
    printf("\n Album: %s .",cancion.album);
    printf("\n Fecha: %d.",cancion.anio);
    printf("\n Genero: %s ",cancion.genero);
    printf("\n Comentario: %s ",cancion.comentario);
    printf("\n Status: %d",cancion.eliminado);
    printf("\n=======================");
}


///ID CANCIONES
int GenerarIDUnicoCanciones(ArbolCanciones* arbol) ///genera un id unico, revisando un arbol dado
{
    int flag=0,id;

        do{
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolCanciones(arbol,id)==0)
        {
            flag=1;
        }
        }while(flag!=1);

    return id;
}

int buscaIDenArbolCanciones (ArbolCanciones *arbol, int id) ///busca un id en arbol canciones, retorna un flag
{
    int flag=0;

        if (arbol)
            {
            if (id == arbol->dato.idCancion)
                {
                    flag=1;
                }
            else
                if (id > arbol->dato.idCancion)
                    {
                        flag = buscaIDenArbolCanciones(arbol->izq,id);
                    }
                else
                    {
                        flag = buscaIDenArbolCanciones(arbol->der,id);
                    }
            }
    return flag;
}


/// PASAJE A ARCHIVO USUARIOS -> *pierde datos*
void pasarArchUsuarioToArbol (ArbolCanciones** arbol)
{ ///Cargar un arbol de un archivo
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion cancionAux;
    if (pArchCanciones){
        while (fread(&cancionAux, sizeof(stCancion), 1, pArchCanciones)>0){
            //MuestraUnUsuario(usuarioAux);
            AgregarCancion(*(&arbol),cancionAux);
            mostrarNodoArbolCancion(*arbol);
            system("pause");
            ///Falta implementar esta parte, agregarle una lista de canciones personal del usuario
            //ArbolCanciones* cons = crearNodoCancion(aux); ///Crea lista doble de playlist.
        }
        fclose(pArchCanciones);
    }
}

void GuardaCancionEnArchivo (ArbolCanciones *arbol,FILE *pArchCanciones)
{
    if(pArchCanciones)
        {
            if(arbol != NULL)
            {
                fwrite(&arbol->dato, sizeof (stCancion),1,pArchCanciones);
                GuardaCancionEnArchivo(arbol->izq,pArchCanciones);
                GuardaCancionEnArchivo(arbol->der,pArchCanciones);
                fclose(pArchCanciones);
                ///ToDo -> sacar coment
                printf("\n cargado exitosa");
            }
        }
}

void muestraArchivoCancion()
{
     FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
     stCancion cancionesAux;
     if(pArchCanciones)
     {
         while(fread(&cancionesAux, sizeof(stCancion), 1, pArchCanciones)>0)
         {
            MuestraUnaCancion(cancionesAux);
         }
         fclose(pArchCanciones);
     }
}


///CARGA RND CANCIONES
stCancion cargaCancionRandom()
{
    stCancion c;

    c.idCancion=0;
    getTituloRand(c.titulo);
    getArtistaRand(c.artista);
    c.duracion=getDuracionRand();
    getAlbumRand(c.album);
    c.anio=getAnioRand();
    getGeneroRand(c.genero);
    c.comentario;
    c.eliminado=0;

    return c;
}

void getTituloRand(char n[])
{
    char pass [][30] = {"asdasd", "Pazczxblo", "zxczxadwq", "qqwewqe","cvbcvb", "tytyerwer","qweqwe","sdfsdfsd","ncvnbvn",
                           "qweqwe","ertert","tyuty","xcvvxcv","asdas","punbvn","sdfger","asdqwe123","4534zdfx","6436cvx","123124zxc",
                           "zxczxvxc34634","123123zxdc","asdasd23565","hjghjdf421","dsad1325t34","asdaswd123","hjklh213","klkl345"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getArtistaRand(char n[])
{
    char pass [][30] = {"asdasd", "Pazczxblo", "zxczxadwq", "qqwewqe","cvbcvb", "tytyerwer","qweqwe","sdfsdfsd","ncvnbvn",
                           "qweqwe","ertert","tyuty","xcvvxcv","asdas","punbvn","sdfger","asdqwe123","4534zdfx","6436cvx","123124zxc",
                           "zxczxvxc34634","123123zxdc","asdasd23565","hjghjdf421","dsad1325t34","asdaswd123","hjklh213","klkl345"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getAlbumRand(char n[])
{
    char pass [][30] = {"asdasd", "Pazczxblo", "zxczxadwq", "qqwewqe","cvbcvb", "tytyerwer","qweqwe","sdfsdfsd","ncvnbvn",
                           "qweqwe","ertert","tyuty","xcvvxcv","asdas","punbvn","sdfger","asdqwe123","4534zdfx","6436cvx","123124zxc",
                           "zxczxvxc34634","123123zxdc","asdasd23565","hjghjdf421","dsad1325t34","asdaswd123","hjklh213","klkl345"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getGeneroRand(char n[])
{
    char pass [][30] = {"asdasd", "Pazczxblo", "zxczxadwq", "qqwewqe","cvbcvb", "tytyerwer","qweqwe","sdfsdfsd","ncvnbvn",
                           "qweqwe","ertert","tyuty","xcvvxcv","asdas","punbvn","sdfger","asdqwe123","4534zdfx","6436cvx","123124zxc",
                           "zxczxvxc34634","123123zxdc","asdasd23565","hjghjdf421","dsad1325t34","asdaswd123","hjklh213","klkl345"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

int getAnioRand()
{
    int anio=2022;

    return anio;
}

int getDuracionRand()
{
    int duracion=300;

    return duracion;
}
