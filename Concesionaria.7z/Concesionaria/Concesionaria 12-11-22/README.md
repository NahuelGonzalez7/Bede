<h1 align="center"> UTN -> TP Final Laboratorio 2 </h1>
<hr>

# Trabajo Práctico Final: integración del contenido <br>
<h3> UTN -> Introducción</h3><br>
Este proyecto se basa en los temas vistos durante la cursada de laboratorio 2, aplicando los temas vistos principalmente recursividad, estructuras, estructuras compuestas y arboles binarios. <br>
Para cumplir esto, creamos una aplicación de concesionaria donde se una un CRUD de empleados y un CRUD de autos.
<hr>
<br>

Con el propósito principal de integrar todo lo aprendido en la materia laboratorio 2 hemos planteado la siguiente problemática: 
* Crear un CRUD.
* Generar una persistencia de datos (empleados y autos). 
* Uso de estructuras.<br> 

Integrantes del grupo: 
* Olevar Isaias.
* Trionfini Juan Pedro.
* Vercellone Nicolás.


