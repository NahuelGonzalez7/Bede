void borrarArchivo(char nombre[])
{
    FILE* archivo = fopen(nombre, "w+b");
    if(archivo != NULL)
    {
        fclose(archivo);
    }
    else
    {
        printf("No se pudo Borrar el archivo personal.\n");
    }
}

int verificarArchivos(char nombre[])
{
    int creado = 0;
    FILE* archivo = fopen(ARCHIVO_PERSONAL, "r+b");
    if(archivo != NULL)
    {
        fclose(archivo);
    }
    else
    {
        archivo = fopen(ARCHIVO_PERSONAL, "wb");
        if(archivo != NULL)
        {
            printf("Archivo personal creado.\n");
            fclose(archivo);
            creado = 1;
        }
        else
        {
            printf("No se pudo generar el archivo personal.\n");
        }
    }
    return creado;
}


/// ARCHIVOS ///

void mostrarListaAutos(nodoAuto* listaAutos)
{
    if(listaAutos != NULL)
    {
        mostrarListaModelo(listaAutos->listaModelo);
        mostrarListaAutos(listaAutos->siguiente);
    }
}

void mostrarMarcasDisponibles(nodoAuto* listaAutos)
{
    if(listaAutos != NULL)
    {
        printf("\t\t\t\t\t\t  %s\n", listaAutos->marca);
        mostrarMarcasDisponibles(listaAutos->siguiente);
    }
}


/// BUSQUEDAS
//POR MARCA
case 1:
        system("cls");
        marcoGeneral();
        tituloCentral("2. Buscar por marca\n",4,159,159);
        char marca[15];
        gotoxy(50,12);printf("Marcas disponibles: \n");
        mostrarMarcasDisponibles(listaAutos);
        gotoxy(50,16);printf("Ingrese Marca: ");
        fflush(stdin);
        gets(marca);
        nodoModelo* listaPorMarca = filtroMarca(listaAutos, marca);
        if(listaPorMarca != NULL)
        {
            printf("\n\t\t\t\t MARCA |   MODELO   |  PRECIO  |   KM    |   A%cO    |  ID   |CANTIDAD\n",165);
            mostrarListaModelo(listaPorMarca);
        } else
        {
            gotoxy(42,17);printf("La marca ingresada (%s) no se encuentra. \n", marca);
        }
        getch();
        break;

        nodoModelo* filtroMarca(nodoAuto* listaAutos,char marca[])
{
    nodoAuto* iterador = listaAutos;
    nodoModelo* listaMarca = inicModelo();

    while(iterador != NULL)
    {
        if(strcmpi(iterador->marca, marca) == 0)
        {
            listaMarca = iterador->listaModelo;
        }
        iterador = iterador->siguiente;
    }
    return listaMarca;
}

//POR ANIO
 case 4:
        system("cls");
        marcoGeneral();
        printf("\t4. Buscar por a%Cio \n\n",164);
        int opcionPorAnio = -1;
        do
        {
            opcionPorAnio = buscarPorAnio_menu();
            buscarPorAnio_case(opcionPorAnio);

        } while(opcionPorAnio != 4);
        break;

/// LAS OPCIONES ADENTRO DEL BUSCAR POR ANIO SON ESTAS
/// -> PASADAS LAS DOS QUE ME SIRVEN
    case 3:;
        //printf("me sale error si no estoy, codeblocks es una mierda");
        double precioMinimo;
        double precioMaximo;
        listaAutos = cargaAutos();
        do
        {
            system("cls");
            marcoGeneral();
            tituloCentral("Por anio entre valores:",4,159,159);
            gotoxy(42,11);printf("\tIngrese el anio minimo: ");
            fflush(stdin);
            scanf("%lf", &precioMinimo);

            if(precioMinimo < 0)
            {
                printf("\t");
                char textoError[30] = "Ingrese un valor positivo";
                escribirTexto(textoError, 50, 1000);
            }
        }
        while(precioMinimo < 0);

        do
        {
            system("cls");
            marcoGeneral();
            tituloCentral("Por anio entre valores:",4,159,159);
            gotoxy(42,11);printf("\tIngrese el anio maximo: ",164);
            fflush(stdin);
            scanf("%lf", &precioMaximo);

            if(precioMaximo < 0)
            {
                printf("\t");
                char textoError[30] = "Ingrese un valor positivo";
                escribirTexto(textoError, 50, 1000);
            }
        }
        while(precioMaximo < 0);


        listaAutos = filtrarRango(listaAutos, precioMinimo, precioMaximo, FILTRAR_ANIO);

        if(listaAutos != NULL)
        {
            gotoxy(42,12);printf("\tLa lista de autos %.0lf - %.0lf \n", precioMinimo, precioMaximo);
            gotoxy(33,14);printf("MARCA |   MODELO   |  PRECIO  |   KM    |   A%cO    |  ID   |CANTIDAD\n",165);
            mostrarListaAutos(listaAutos);
        }
        else
        {
            gotoxy(42,15);printf("\tNo se encontraron autos %.0lf - %.0lf \n", precioMinimo, precioMaximo);
        }
        getch();
        break;
