#ifndef MENUS_H_INCLUDED
#define MENUS_H_INCLUDED
#include "usuarios.h"
#include "canciones.h"
void MenuPrincipal();
void menuLogin();
void menuRegistro();
void menuUsuario(stUsuario u);
void menuAdmin(stUsuario u);
void menuGestionarCanciones(stUsuario u);
void menuGestionarUsuarios(stUsuario u);



#endif // MENUS_H_INCLUDED
