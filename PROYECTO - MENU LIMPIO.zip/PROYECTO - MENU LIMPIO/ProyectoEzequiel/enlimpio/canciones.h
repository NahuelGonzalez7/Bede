#ifndef CANCIONES_H_INCLUDED
#define CANCIONES_H_INCLUDED
#define AR_CANCIONES "canciones.dat"
#define AR_USUARIOS "usuarios.dat"
#include <stdio.h>


typedef struct {
 int idCancion;
 char titulo[30];
 char artista[20];
 int duracion;
 char album[20];
 int anio;
 char genero[20];
 char comentario[100];
 int eliminado; // indica 1 o 0 si la canci�n fue eliminada
 int idCancionFavorita;
} stCancion;


///ARBOLES Y NODO CANCION

typedef struct ArbolCanciones ArbolCanciones;
struct ArbolCanciones{
    stCancion dato;
    struct ArbolCanciones *izq;
    struct ArbolCanciones *der;
};

typedef struct nodoCancion nodoCancion;
 struct nodoCancion{
    ///LISTAS DE CANCIONES
    int id;
    stCancion cancion;
    nodoCancion* ante;
    nodoCancion* sig;
};


///CANCIONES
ArbolCanciones* inicListaC();
ArbolCanciones* crearNodoArbolCancion (stCancion dato);
void AgregarCancion(ArbolCanciones** arbol, stCancion dato);
void mostrarNodoArbolCancion(ArbolCanciones *arbol);
void preorderCancion (ArbolCanciones* arbol);
void inorderCancion(ArbolCanciones* arbol);
void MuestraUnaCancion(stCancion cancion);
int GenerarIDUnicoCanciones(ArbolCanciones* arbol);
int buscaIDenArbolCanciones (ArbolCanciones *arbol, int id);
void GuardaCancionEnArchivo (ArbolCanciones *arbol,FILE *pArchCanciones);
void muestraArchivoCancion();
nodoCancion* inicNodoCancion();
void *AgregarNodo(nodoCancion** lista, ArbolCanciones *arbol,int id);///Recibe lista a donde guardar, arbol donde buscar e id de cancion que agregar.
nodoCancion* crearNodoCancion(ArbolCanciones* dato);
stCancion cargarCancion();


///CARGA RND
stCancion cargaCancionRandom();
void getTituloRand(char n[]);
void getArtistaRand(char n[]);
void getAlbumRand(char n[]);
void getGeneroRand(char n[]);
int getAnioRand();
int getDuracionRand();
#endif // CANCIONES_H_INCLUDED
