

#include "canciones.h"


///ARBOL CANCIONES

ArbolCanciones* inicArbolCanciones()///CREAR CANCION Y AGREGARLA AL ARBOL
{
    return NULL;
}

ArbolCanciones* crearNodoArbolCancion (stCancion dato){
    ArbolCanciones* aux = (ArbolCanciones*) malloc(sizeof(ArbolCanciones));

    aux->dato = dato;
    aux->der = NULL;
    aux->izq = NULL;

    return aux;
}

void AgregarCancion(ArbolCanciones** arbol, stCancion dato)
{
    ArbolCanciones *iterator = *arbol;

    if (iterator == NULL){
        (*arbol) = crearNodoArbolCancion(dato);
        }
        else if (dato.idCancion > (iterator->dato.idCancion))
        {
            return AgregarCancion(&(iterator->der), dato);
        } else {
            return AgregarCancion(&(iterator->izq), dato);
        }
}

///NODO CANCION

nodoCancion* inicNodoCancion()
{
    return NULL;
}


void *AgregarNodo(nodoCancion** lista, ArbolCanciones *arbol,int id)///Recibe lista a donde guardar, arbol donde buscar e id de cancion que agregar.
{
    ArbolCanciones *iterator= inicArbolCanciones();
    nodoCancion *dato=inicNodoCancion();
    BuscaCancionXID(&dato,arbol,id);

    if((*lista)==NULL)
    {
        (*lista) = dato;

    }
    else
    {
     AgregarNodo(&(*lista)->sig,arbol,id);
    }
}

///MUESTRA CANCIONES

void preorderCancion (ArbolCanciones* arbol)///Mostrar ARBOL
{
    if(arbol!=NULL)
        {
            mostrarNodoArbolCancion(arbol);
            preorderCancion(arbol->izq);
            preorderCancion(arbol->der);
        }
}

void inorderCancion(ArbolCanciones* arbol)
{
    if(arbol!= NULL)
    {
        preorderCancion(arbol->izq);
        mostrarNodoArbolCancion(arbol);
        preorderCancion(arbol->der);
    }
}

void mostrarNodoArbolCancion(ArbolCanciones *arbol)
{
    if(arbol)
    {
        MuestraUnaCancion(arbol->dato);
    }
}

void MuestraUnaCancion(stCancion cancion)///MUESTRA UNA CANCION
{
    printf("\n=======================");
    printf("\n ID: %d .",cancion.idCancion);
    printf("\n Artista: %s",cancion.artista);
    printf("\n Titulo: %s",cancion.titulo);
    printf("\n Duracion: %d s",cancion.duracion);
    printf("\n Album: %s .",cancion.album);
    printf("\n Fecha: %d.",cancion.anio);
    printf("\n Genero: %s ",cancion.genero);
    printf("\n Comentario: %s ",cancion.comentario);
    printf("\n Status: %d",cancion.eliminado);
    printf("\n=======================");
}

/// TODO->PROBAR FUNCIONAMIENTO
void MuestraListaDoble(nodoCancion* lista)
{
    if(lista!=NULL)
    {
        MuestraUnaCancion(lista->cancion);
        MuestraListaDoble(lista->sig);
    }
}

///ID CANCIONES
int GenerarIDUnicoCanciones(ArbolCanciones* arbol) ///genera un id unico, revisando un arbol dado
{
    int flag=0,id;

        do{
        srand(time(NULL));
        id=rand() % 10000;
        if(buscaIDenArbolCanciones(arbol,id)==0)
        {
            flag=1;
        }
        }while(flag!=1);

    return id;
}

int buscaIDenArbolCanciones (ArbolCanciones *arbol, int id) ///busca un id en arbol canciones, retorna un flag
{
    int flag=0;

        if (arbol)
            {
            if (id == arbol->dato.idCancion)
                {
                    flag=1;
                }
            else
                if (id > arbol->dato.idCancion)
                    {
                        flag = buscaIDenArbolCanciones(arbol->izq,id);
                    }
                else
                    {
                        flag = buscaIDenArbolCanciones(arbol->der,id);
                    }
            }
    return flag;
}


///ARCHIVO CANCIONES










///CARGA RND CANCIONES
stCancion cargaCancionRandom()
{
    stCancion c;

    c.idCancion=0;
    getTituloRand(c.titulo);
    getArtistaRand(c.artista);
    c.duracion=getDuracionRand();
    getAlbumRand(c.album);
    c.anio=getAnioRand();
    getGeneroRand(c.genero);
    GetComentarioDefault(c.comentario);
    c.eliminado=0;


    return c;
}

void getTituloRand(char n[])
{
    char pass [][30] = {"Solia", "La Bachata", "La Carretera", "Impala","Loser", "Adore You","Te Amo","Me Gustas Tu","Creo",
                           "Lucky","Yellow","Lo Quiero Todo","Disfruto","Tan Lejos","Traicionero","Nada","Perdido","Fuego","Nunca Quise","Prohibido",
                           "Sorry","Rockstar","Faded","My Way","In My Mind","Alone","Rude","Ride It"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getArtistaRand(char n[])
{
    char pass [][30] = {"Rihanna", "Don Omar", "Makano", "Adele","Sia", "Tiesto","Martin Garrix","Avicci","Calvin Harris",
                           "Dua Lipa","Coldplay","Daddy Yankee","Justin Bieber","Post Malone","Lady Gaga","Sam Smith","Ariana Grande","Callejeros","Duki","Enya",
                           "Moby","Gorillaz","Bad Bunny","Bizarrap","Drake","Porta","Los Piojos","AK"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getAlbumRand(char n[])
{
    char pass [][30] = {"Thriller", "Rumours", "Pet Sounds", "Music Box","One", "Millennium","Baby One More Time","Titanic","Bad",
                           "Nevermind","Metalica","Spice","Grease","Supernatural","Tapestry","Daydream","Romanza","Legend","Believe","Janet",
                           "Whitney","Purple Rain","The Rain","History","Signos","Giros","Oasis","Forth"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

void getGeneroRand(char n[])
{
    char pass [][30] = {"Trap", "Tango", "Techno", "Jazz","Soul", "Blues","Rock and Roll","Metal","Disco",
                           "Pop","Reggaeton","Country","House","Salsa","Flamenco","Hip Hop","Reggae","Ranchera","Rap","Cumbia",
                           "Bachata","Samba","Kpop","Heavy Metal","Dubstep","Folclore","Lirico","Gospel"
                          };
    strcpy (n, pass[rand()%(sizeof(pass)/30)]);
}

int getAnioRand()
{
    int nro, min=1950,max=2022;

    srand(time(NULL));
    nro=min+rand()%(max-min);

    return nro;
}

int getDuracionRand()
{
    int nro, min=95,max=300;

    srand(time(NULL));
    nro=min+rand()%(max-min);

    return nro;
}


void GetComentarioDefault(char n[])
{

    char comment[15] = {"no comments"};
    strcpy(n,comment);

}

/// FUNCIONES FUNCIONANDO XD

nodoCancion* crearNodoCancion(ArbolCanciones* dato)
{
    nodoCancion* aux= (nodoCancion*) malloc(sizeof(nodoCancion));
    aux->cancion=dato->dato;
    aux->ante=NULL;
    aux->sig=NULL;

    return aux;
}

/// CREA UN NODO PARA AGREGAR UNA LISTA DE CANCIONES FAVORITAS, POR ESO RECIBE EL ID
nodoCancion* crearNodoCancionFavorita(stCancion cancion,int id)
{
    nodoCancion* aux= (nodoCancion*) malloc(sizeof(nodoCancion));
    aux->cancion = cancion;
    aux->cancion.idCancionFavorita = id; ///EL ID QUE RECIBE POR PARAMETRO ES EL DEL USUARIO DUENIO DE LA LISTA
    aux->ante=NULL;
    aux->sig=NULL;

    return aux;
}

/// CREA UN NODO DE UNA LISTA COMUN
nodoCancion* crearNodoListaCancion(stCancion cancion)
{
    nodoCancion* aux= (nodoCancion*) malloc(sizeof(nodoCancion));
    aux->cancion=cancion;
    aux->ante=NULL;
    aux->sig=NULL;

    return aux;
}

//funcionando
nodoCancion * agregarAlPrincipio(nodoCancion * lista, nodoCancion * nuevoNodo)
{
    nuevoNodo->sig = lista;
    if(lista!=NULL)
    {
        lista->ante=nuevoNodo;
    }
    return nuevoNodo;
}

nodoCancion* cargaCancion()
{
    nodoCancion* listaCancion = inicNodoCancion(listaCancion);
    FILE* archivo = fopen(AR_CANCIONES, "r+b");

    if(archivo != NULL)
    {
        stCancion canciones;
        ///CARGA DESDE LA ULTIMA POSICION DEL ARCHIVO
        while(fread(&canciones, sizeof(stCancion), 1, archivo) > 0)
        {
            ///
            nodoCancion* nuevoNodo = crearNodoListaCancion(canciones);
            listaCancion = agregarAlPrincipio(listaCancion, nuevoNodo);
        }
        fclose(archivo);
    }
    else
    {
        printf("Error al abrir el archivo 'canciones'\n");
    }
    return listaCancion;
}

void guardarListaCancion(nodoCancion * listaCancion)
{
    FILE* archivo = fopen(AR_CANCIONES, "a+b");
    if(archivo != NULL)
    {
        // recorrer la lista de canciones y guardar....
        int contador = 0;

        stCancion cancionACargar;
        nodoCancion * lista = listaCancion;

        if(lista != NULL)
        {
            nodoCancion* iteradorCancion = lista;
            while(iteradorCancion != NULL)
            {

                    cancionACargar = iteradorCancion->cancion;
                    cancionACargar.idCancion = contador;
                    contador++;

                    fwrite(&cancionACargar, sizeof(stCancion), 1, archivo);

                iteradorCancion = iteradorCancion->sig;
            }
        }

        fclose(archivo);
    }
    else
    {
        printf("Error al abrir el archivo en guardarListaCancion()");
    }
}

void mostrarNodoLista(nodoCancion* nuevoNodo)
{
    MuestraUnaCancion(nuevoNodo->cancion);
}

void muestraListadobleIterar(nodoCancion* lista)
{
    nodoCancion * seg = lista;
    while (seg != NULL)
    {
        printf("\n ID LISTA: %d\n",seg->id);
        mostrarNodoLista(seg);
        seg = seg->sig;
    }
}

///TODO PROBAR -> FUNCIONABA (FUNCIONABA EN EL OTRO PROYECTO, EN ESTE NO)
void muestraArchivoCancion() //MUESTRA LAS CANCIONES CARGADAS EN EL ARCHIVO DE CANCIONES
{
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion cancionesAux;
    if(pArchCanciones)
    {
        while(fread(&cancionesAux, sizeof(stCancion), 1, pArchCanciones)>0)
        {
            MuestraUnaCancion(cancionesAux);
        }
        fclose(pArchCanciones);
    }
}


///Carga un arbol de canciones desde un archivo de canciones
///TODO PROBAR -> FUNCIONA.
void pasarArchCancionToArbol (ArbolCanciones** arbol)
{
    FILE *pArchCanciones = fopen(AR_CANCIONES, "rb");
    stCancion cancionAux;
    if (pArchCanciones)
    {
        while (fread(&cancionAux, sizeof(stCancion), 1, pArchCanciones)>0)
        {
            AgregarCancion(*(&arbol),cancionAux);
            sleep(1);
        }
        fclose(pArchCanciones);
    }
}

///Guarda una cancion en el archivo a partir de un Arbol de canciones
///TODO PROBAR -> FUNCIONA.
void GuardaCancionEnArchivo (ArbolCanciones *arbol,FILE *pArchCanciones)
{
    if(pArchCanciones)
    {
        if(arbol != NULL)
        {
            fwrite(&arbol->dato, sizeof (stCancion),1,pArchCanciones);
            GuardaCancionEnArchivo(arbol->izq,pArchCanciones);
            GuardaCancionEnArchivo(arbol->der,pArchCanciones);
            printf("\n carga exitosa");
        }
        fclose(pArchCanciones);
    }
}

///ALTA CANCION
///TODO -> PROBAR
stCancion cargarCancion()
{
    stCancion cancion;
    printf("REGISTRO DE CANCION\n\n");

    printf("INGRESE TITULO DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.titulo);

    printf("\nINGRESE EL ARTISTA DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.artista);

    printf("\nINGRESE LA DURACION DE LA CANCION: ");
    fflush(stdin);
    scanf("%i", &cancion.duracion);

    printf("\nINGRESE EL ALBUM DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.album);

    printf("\nINGRESE EL ANIO DE LA CANCION: ");
    fflush(stdin);
    scanf("%i", &cancion.anio);

    printf("\nINGRESE EL GENERO DE LA CANCION: ");
    fflush(stdin);
    gets(cancion.genero);

    printf("\nINGRESE UN COMENTARIO: ");
    fflush(stdin);
    gets(cancion.comentario);

    cancion.eliminado = 0;

    return cancion;
}


